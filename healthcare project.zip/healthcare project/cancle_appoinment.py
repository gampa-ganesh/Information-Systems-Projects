import customtkinter as ctk
from tkinter import messagebox
import sys
from config import connect_db

# Retrieve `user_id` passed as a command-line argument
try:
    current_user_id = int(sys.argv[1])
except (IndexError, ValueError):
    messagebox.showerror("Error", "User ID not provided. Please log in again.")
    sys.exit(1)

# Function to fetch appointment history with additional details
def get_appointment_history(user_id):
    """
    Fetches all appointments for the current patient along with doctor details,
    excluding canceled and completed appointments.
    """
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT a.appointment_id, CONCAT(u.first_name, ' ', u.last_name) AS doctor_name, 
               d.specialization, a.appointment_date, a.status 
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.doctor_id
        JOIN users u ON d.user_id = u.user_id
        WHERE a.patient_id = %s AND a.status NOT IN ('canceled', 'completed')
        ORDER BY a.appointment_date DESC
    """, (user_id,))
    appointments = cursor.fetchall()
    conn.close()
    return appointments

# Function to confirm and cancel an appointment
def confirm_cancel(appointment_id, root):
    """
    Confirms and cancels the selected appointment by updating the database.
    """
    response = messagebox.askyesno("Confirm Cancelation", "Are you sure you want to cancel this appointment?")
    if response:
        try:
            conn = connect_db()
            cursor = conn.cursor()

            # Update the specific appointment status to 'canceled'
            cursor.execute("""
                UPDATE appointments
                SET status = 'canceled'
                WHERE appointment_id = %s
            """, (appointment_id,))
            conn.commit()
            conn.close()

            # Close the window and show a success message
            root.destroy()
            messagebox.showinfo("Canceled", "Your appointment has been canceled successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to cancel appointment: {e}")

# Main Cancel Appointment Function
def cancel_appointment():
    """
    Displays a window to show all active appointments and allows the user to cancel them.
    """
    root = ctk.CTk()
    root.title("Cancel Appointment")
    root.geometry("700x500")
    root.configure(fg_color="#c0d9f0")

    # Center the window
    window_width = 700
    window_height = 500
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x_cordinate = int((screen_width / 2) - (window_width / 2))
    y_cordinate = int((screen_height / 2) - (window_height / 2))
    root.geometry(f"{window_width}x{window_height}+{x_cordinate}+{y_cordinate}")

    # Fetch user appointments
    appointments = get_appointment_history(current_user_id)

    # Title for the cancel appointment window
    title_label = ctk.CTkLabel(root, text="Cancel an Appointment", font=("Helvetica", 20, "bold"), text_color="#001f4d")
    title_label.pack(pady=20)

    if appointments:
        # Create a scrollable frame for appointments
        canvas = ctk.CTkCanvas(root, width=680, height=400, bg="#c0d9f0", highlightthickness=0)
        scrollbar = ctk.CTkScrollbar(root, orientation="vertical", command=canvas.yview)
        scrollable_frame = ctk.CTkFrame(canvas, fg_color="#c0d9f0", corner_radius=10)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Display a list of active appointments
        for appt in appointments:
            appointment_id, doctor_name, specialization, appointment_date, status = appt
            # Frame for each appointment
            appointment_frame = ctk.CTkFrame(scrollable_frame, fg_color="white", corner_radius=10)
            appointment_frame.pack(fill="x", padx=20, pady=10)

            # Use a grid layout to align text and button properly
            appointment_frame.columnconfigure(0, weight=3)  # Text column
            appointment_frame.columnconfigure(2, weight=1)  # Button column

            # Appointment information
            appointment_info = (
                f"Doctor Name: {doctor_name} ({specialization})\n"
                f"Date & Time: {appointment_date}\n"
                f"Status: {status}"
            )
            info_label = ctk.CTkLabel(appointment_frame, text=appointment_info, font=("Arial", 15),
                                      text_color="#00172b", justify="left")
            info_label.grid(row=0, column=0, sticky="w", padx=10, pady=10)

            # Cancel button aligned to the right
            cancel_button = ctk.CTkButton(
                appointment_frame,
                text="Cancel",
                fg_color="#ff3300",
                text_color="white",
                command=lambda appt_id=appointment_id: confirm_cancel(appt_id, root)  # Corrected lambda
            )
            cancel_button.grid(row=0, column=1, sticky="e", padx=(20, 50), pady=10)
    else:
        no_appt_label = ctk.CTkLabel(root, text="No active appointments to cancel.", font=("Arial", 15), text_color="#666666")
        no_appt_label.pack(anchor="center", padx=20, pady=20)

    # Run the main loop
    root.mainloop()


# Run the Cancel Appointment Feature
if __name__ == "__main__":
    cancel_appointment()
