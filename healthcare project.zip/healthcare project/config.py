import mysql.connector

def connect_db():
    return mysql.connector.connect(
        host="141.209.241.57",
        user="gampa2g",
        password="mypass",
        database="BIS698M_GRP6",
        port=3306
    )
