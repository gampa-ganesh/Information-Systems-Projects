from tkinter import messagebox
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import inch
from datetime import datetime
import os
from config import connect_db  # Import the database connection function


def generate_completed_appointments_report(current_user_id, first_name, last_name):
    """
    Generates a PDF report of completed appointments for the doctor, with a unique file name.
    """
    try:
        conn = connect_db()
        cursor = conn.cursor()

        # Fetch completed appointments for the logged-in doctor
        cursor.execute("""
            SELECT 
                CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
                p.gender,
                p.date_of_birth,
                a.appointment_date
            FROM 
                appointments a
            JOIN 
                users p ON a.patient_id = p.user_id
            JOIN 
                doctors d ON a.doctor_id = d.doctor_id
            WHERE 
                a.status = 'completed' AND d.user_id = %s
            ORDER BY 
                a.appointment_date DESC
        """, (current_user_id,))
        appointments = cursor.fetchall()
        conn.close()

        # Total number of completed appointments
        total_appointments = len(appointments)

        if appointments:
            # Define the PDF file path with a unique name
            output_dir = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\reports"
            os.makedirs(output_dir, exist_ok=True)

            # Add a timestamp to the file name to make it unique
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            file_name = f"Completed_Appointments_{first_name}_{last_name}_{timestamp}.pdf"
            file_path = os.path.join(output_dir, file_name)

            # Create a PDF document
            doc = SimpleDocTemplate(
                file_path,
                pagesize=letter,
                rightMargin=30,
                leftMargin=30,
                topMargin=30,
                bottomMargin=18,
            )

            # Create a list to hold the elements for the PDF
            elements = []

            # Set up styles
            styles = getSampleStyleSheet()
            styles.add(ParagraphStyle(name='CenterTitle', alignment=TA_CENTER, fontSize=18, leading=22, spaceAfter=20))
            styles.add(ParagraphStyle(name='CustomBodyText', fontSize=12, spaceAfter=12))  # Renamed style

            # Add a title
            title = Paragraph(f"Completed Appointments Report for Dr. {first_name} {last_name}", styles['CenterTitle'])
            elements.append(title)

            # Add report generation date
            report_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            date_paragraph = Paragraph(f"Report generated on: {report_date}", styles['CustomBodyText'])
            elements.append(date_paragraph)

            # Add total completed appointments
            total_paragraph = Paragraph(f"<b>Total Completed Appointments: {total_appointments}</b>",
                                        styles['CustomBodyText'])
            elements.append(total_paragraph)
            elements.append(Spacer(1, 12))

            # Create table data
            data = []
            # Table header
            data.append(['Patient Name', 'Gender', 'Date of Birth', 'Appointment Date'])

            # Add appointment data
            for appointment in appointments:
                patient_name, gender, dob, appointment_date = appointment
                data.append([
                    patient_name,
                    gender,
                    dob.strftime('%Y-%m-%d'),
                    appointment_date.strftime('%Y-%m-%d %H:%M')
                ])

            # Create the table
            table = Table(data, repeatRows=1)

            # Add style to the table
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#003366')),  # Header background
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),  # Header text color
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),  # Header font
                ('FONTSIZE', (0, 0), (-1, 0), 12),  # Header font size
                ('BOTTOMPADDING', (0, 0), (-1, 0), 10),  # Header bottom padding
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),  # Body background
                ('GRID', (0, 0), (-1, -1), 1, colors.black),  # Table grid
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f2f2f2')]),
                # Alternating row colors
            ]))

            elements.append(table)

            # Build the PDF
            doc.build(elements)

            messagebox.showinfo("Success", f"Report saved at: {file_path}")
        else:
            messagebox.showinfo("No Data", "No completed appointments found.")

    except Exception as e:
        messagebox.showerror("Error", f"Failed to generate report: {e}")
