import customtkinter as ctk
from tkinter import messagebox, Canvas, Scrollbar
from config import connect_db
import sys
import re

# Initialize main window for booking appointments
root = ctk.CTk()
root.title("Book an Appointment")
root.geometry("800x600")
root.configure(fg_color="#f4f6f9")  # Background color for the window

# Center the window on the screen
window_width = 800
window_height = 600
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x_cordinate = int((screen_width / 2) - (window_width / 2))
y_cordinate = int((screen_height / 2) - (window_height / 2))
root.geometry(f"{window_width}x{window_height}+{x_cordinate}+{y_cordinate}")

# Set appearance mode and default theme for consistency in colors
ctk.set_appearance_mode("light")  # Set to "dark" if preferred
ctk.set_default_color_theme("blue")  # Use a default color theme

# Retrieve `user_id` from command-line arguments
try:
    current_user_id = int(sys.argv[1])
except (IndexError, ValueError):
    messagebox.showerror("Error", "User ID not provided. Please log in again.")
    root.destroy()
    sys.exit(1)


# Utility Function: Extract the zip code from an address string
def extract_zip_code(address):
    match = re.search(r"\b\d{5}\b", address)
    return match.group(0) if match else None


# Utility Function: Fetch patient's zip code from their address
def get_patient_zipcode(user_id):
    try:
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT address FROM users WHERE user_id = %s", (user_id,))
        result = cursor.fetchone()
        conn.close()
        if result:
            return extract_zip_code(result[0])  # Extract zip code from patient's address
        return None
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching patient address: {e}")
        return None


# Function to fetch doctors and availability filtered by zip code
def get_doctor_availability_nearby(patient_zipcode):
    try:
        conn = connect_db()
        cursor = conn.cursor()

        if patient_zipcode:
            # Fetch doctors with matching zip code, unbooked slots, and user details (name, contact)
            cursor.execute("""
                SELECT CONCAT(u.first_name, ' ', u.last_name) AS doctor_name, u.email AS contact,
                       d.doctor_id, d.specialization, d.clinic_address, a.date, a.time, a.availability_id
                FROM users u
                JOIN doctors d ON u.user_id = d.user_id
                JOIN doctor_availability a ON d.doctor_id = a.doctor_id
                LEFT JOIN appointments ap ON a.doctor_id = ap.doctor_id 
                    AND CONCAT(a.date, ' ', a.time) = ap.appointment_date
                    AND ap.status = 'booked'
                WHERE ap.appointment_id IS NULL AND d.clinic_address LIKE %s
                ORDER BY a.date, a.time;
            """, (f"%{patient_zipcode}%",))
            doctors_with_availability = cursor.fetchall()

            # If no matching doctors are found, fetch all doctors with unbooked slots
            if not doctors_with_availability:
                cursor.execute("""
                    SELECT CONCAT(u.first_name, ' ', u.last_name) AS doctor_name, u.email AS contact,
                           d.doctor_id, d.specialization, d.clinic_address, a.date, a.time, a.availability_id
                    FROM users u
                    JOIN doctors d ON u.user_id = d.user_id
                    JOIN doctor_availability a ON d.doctor_id = a.doctor_id
                    LEFT JOIN appointments ap ON a.doctor_id = ap.doctor_id 
                        AND CONCAT(a.date, ' ', a.time) = ap.appointment_date
                        AND ap.status = 'booked'
                    WHERE ap.appointment_id IS NULL
                    ORDER BY a.date, a.time;
                """)
                doctors_with_availability = cursor.fetchall()
        else:
            # Fetch all doctors and unbooked slots
            cursor.execute("""
                SELECT CONCAT(u.first_name, ' ', u.last_name) AS doctor_name, u.email AS contact,
                       d.doctor_id, d.specialization, d.clinic_address, a.date, a.time, a.availability_id
                FROM users u
                JOIN doctors d ON u.user_id = d.user_id
                JOIN doctor_availability a ON d.doctor_id = a.doctor_id
                LEFT JOIN appointments ap ON a.doctor_id = ap.doctor_id 
                    AND CONCAT(a.date, ' ', a.time) = ap.appointment_date
                    AND ap.status = 'booked'
                WHERE ap.appointment_id IS NULL
                ORDER BY a.date, a.time;
            """)
            doctors_with_availability = cursor.fetchall()

        conn.close()
        return doctors_with_availability
    except Exception as e:
        messagebox.showerror("Database Error", f"Error fetching doctor availability: {e}")
        return []


# Function to book an appointment
def book_appointment(doctor_id, date, time):
    try:
        conn = connect_db()
        cursor = conn.cursor()

        # Combine date and time into a datetime string
        appointment_date = f"{date} {time}"

        # Insert a record into the appointments table with status 'booked'
        cursor.execute("""
            INSERT INTO appointments (patient_id, doctor_id, appointment_date, status)
            VALUES (%s, %s, %s, 'booked')
        """, (current_user_id, doctor_id, appointment_date))

        conn.commit()
        conn.close()

        # Success message
        messagebox.showinfo("Success", "Appointment booked successfully!")
        root.destroy()  # Close the window after booking
    except Exception as e:
        messagebox.showerror("Database Error", f"Error booking appointment: {e}")



# Fetch the patient's zip code
patient_zipcode = get_patient_zipcode(current_user_id)

# Fetch doctor availability based on the patient's zip code
doctor_availability = get_doctor_availability_nearby(patient_zipcode)

# Create a scrollable frame
canvas = Canvas(root, bg="#f4f6f9", highlightthickness=0)
scrollbar = Scrollbar(root, orient="vertical", command=canvas.yview)
scrollable_frame = ctk.CTkFrame(canvas, fg_color="white", corner_radius=10)

scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
)

canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)

canvas.pack(side="left", fill="both", expand=True, padx=20, pady=5)  # Reduced bottom padding
scrollbar.pack(side="right", fill="y")

# Title
title_label = ctk.CTkLabel(scrollable_frame, text="Available Doctors and Slots", font=("Arial", 18, "bold"),
                           text_color="#0072ff")
title_label.pack(anchor="n", pady=10)  # Reduced vertical padding

# Display doctors with available slots
if doctor_availability:
    for doctor in doctor_availability:
        doctor_name, contact, doctor_id, specialization, clinic_address, date, time, availability_id = doctor
        doctor_info = (
            f"Doctor Name: {doctor_name}\n"
            f"Contact: {contact}\n"
            f"Specialization: {specialization}\n"
            f"Clinic Address: {clinic_address}\n"
            f"Date: {date}\n"
            f"Time: {time}"
        )

        # Doctor info label with padding
        doctor_label = ctk.CTkLabel(scrollable_frame, text=doctor_info, font=("Arial", 14), text_color="#333333",
                                    justify="left")
        doctor_label.pack(anchor="w", padx=15, pady=5)

        # Book Appointment Button
        book_button = ctk.CTkButton(
            scrollable_frame,
            text="Book Appointment",
            fg_color="#0072ff",
            text_color="white",
            command=lambda doc_id=doctor_id, d=date, t=time: book_appointment(doc_id, d, t)
        )
        book_button.pack(anchor="e", padx=15, pady=5)
else:
    # No Availability Message
    no_doctor_label = ctk.CTkLabel(scrollable_frame, text="No available doctors or slots.", font=("Arial", 14),
                                   text_color="#666666")
    no_doctor_label.pack(anchor="center", padx=20, pady=20)

# Run the main loop
root.mainloop()
