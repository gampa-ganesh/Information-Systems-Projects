import tkinter as tk
import customtkinter as ctk
from PIL import Image, ImageTk
import os
import sys
import subprocess
from tkinter import messagebox
import threading

# Add the directory of instructions_popup.py and cleanup_service.py to the Python path
sys.path.append(r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project")

# Import the required modules
from instructions_popup import open_instructions_window
import cleanup_service

# Function to start the cleanup service
def start_cleanup_service():
    threading.Thread(target=cleanup_service.schedule_expired_availability_removal, daemon=True).start()


# Start the cleanup service in the background
start_cleanup_service()

# Initialize the main window
root = ctk.CTk()
root.title("Home Page")
root.geometry("1100x550")
root.configure(fg_color="#ffffff")

# Set up relative paths for images
base_dir = os.path.dirname(__file__)  # Directory where the script is located
main_image_path = os.path.join(base_dir, "picture", "home_page.jpg")

# Load and resize the main content frame image
main_image = Image.open(main_image_path).resize((600, 450), Image.LANCZOS)
main_photo = ImageTk.PhotoImage(main_image)

# Header Frame
header_frame = ctk.CTkFrame(root, fg_color="#001f4d", height=100, width=1100)
header_frame.pack(side="top", fill="x")

# Bold Text in Header for "DocLink" title only
header_text_label = ctk.CTkLabel(header_frame, text="DocLINK",
                                 font=("Gill Sans Ultra Bold", 25), text_color="white")
header_text_label.pack(side="left", padx=50, pady=10)

# Paths to the login and signup pages
login_page_path = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\signin.py"
signup_page_path = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\signup.py"

# Function to open the login page
def open_login_page():
    if os.path.exists(login_page_path):
        root.destroy()  # Close the current window
        try:
            subprocess.run([sys.executable, login_page_path])  # Open the login page
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open Login page. Error: {e}")
    else:
        messagebox.showerror("Error", f"Login page not found at {login_page_path}")

# Function to open the signup page
def open_signup_page():
    if os.path.exists(signup_page_path):
        root.destroy()  # Close the current window
        try:
            subprocess.run([sys.executable, signup_page_path])  # Open the signup page
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open Signup page. Error: {e}")
    else:
        messagebox.showerror("Error", f"Signup page not found at {signup_page_path}")

# Right-aligned Login and Signup Buttons with default font
login_button = ctk.CTkButton(
    header_frame,
    text="Log In",
    width=136,
    font=("Arial", 15, "bold"),
    fg_color="#001f4d",
    text_color="white",
    corner_radius=20,
    border_color="white",
    border_width=0,
    command=open_login_page
)
login_button.pack(side="right", padx=15, pady=10)

signup_button = ctk.CTkButton(
    header_frame,
    text="Sign Up",
    width=136,
    font=("Arial", 15, "bold"),
    fg_color="#001f4d",
    text_color="white",
    corner_radius=20,
    border_color="white",
    border_width=0,
    command=open_signup_page
)
signup_button.pack(side="right", padx=15, pady=10)

# Main Content Frame
content_frame = ctk.CTkFrame(root, fg_color="#ffffff")
content_frame.pack(pady=20, padx=20, fill="both", expand=True)

# Left Side (Text Content)
text_frame = ctk.CTkFrame(content_frame, fg_color="#ffffff")
text_frame.grid(row=0, column=0, padx=30, pady=20, sticky="n")

main_message_label = ctk.CTkLabel(
    text_frame,
    text="DocLink: Doctor Any Time",
    font=("Verdana", 28, "bold"),
    text_color="#1d4ed8",
    anchor="w"
)
main_message_label.pack(anchor="w", pady=(20, 20))

description_label = ctk.CTkLabel(
    text_frame,
    text=(
        "See a doctor or therapist from home using your phone, tablet, or computer."
        "Doctors can set their availability, allowing patients to easily find and book appointments that fit their schedules.\n\n"
        "For emergencies, please call 911"
    ),
    font=("Arial", 14),
    text_color="#011557",
    anchor="w",
    justify="left",
    wraplength=400
)
description_label.pack(anchor="w", pady=10)

# "Find Out More" Button
doctor_now_button = ctk.CTkButton(
    text_frame,
    text="How To Use ?",
    width=200,
    height=40,
    font=("Arial", 14, "bold"),
    fg_color="#001f4d",
    text_color="white",
    corner_radius=20,
    command=lambda: open_instructions_window(root),  # Call the popup function
)
doctor_now_button.pack(anchor="w", pady=20)

# Right Side (Main Content Image)
main_image_label = tk.Label(content_frame, image=main_photo, bg="#ffffff")
main_image_label.image = main_photo  # Keep reference to avoid garbage collection
main_image_label.grid(row=0, column=1, padx=30, pady=20, sticky="e")

# Configure the grid layout for spacing
content_frame.grid_columnconfigure(0, weight=1)
content_frame.grid_columnconfigure(1, weight=1)

root.mainloop()
