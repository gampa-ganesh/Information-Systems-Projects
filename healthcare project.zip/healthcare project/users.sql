DROP TABLE IF EXISTS users;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    date_of_birth DATE NOT NULL,
    role ENUM('doctor', 'patient') NOT NULL,
    address TEXT,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);
SELECT * FROM users;
SELECT * FROM doctors;
ALTER TABLE users 
ADD COLUMN phone_number VARCHAR(15),
ADD COLUMN gender ENUM('male', 'female', 'other');

CREATE TABLE appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATETIME NOT NULL,
    status ENUM('booked', 'completed', 'canceled') DEFAULT 'booked',
    FOREIGN KEY (patient_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON DELETE CASCADE
);
ALTER TABLE users ENGINE=InnoDB;
ALTER TABLE doctors ENGINE=InnoDB;
ALTER TABLE appointments ENGINE=InnoDB;

SHOW COLUMNS FROM users;
SHOW COLUMNS FROM doctors;

ALTER TABLE users ENGINE=InnoDB;
ALTER TABLE doctors ENGINE=InnoDB;
CREATE TABLE doctors (
    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    specialization VARCHAR(100),
    clinic_address TEXT,
    availability JSON,  -- Store availability as JSON with days and times
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

ALTER TABLE users ADD COLUMN profile_picture VARCHAR(255);
SET SQL_SAFE_UPDATES = 0;

UPDATE doctors SET availability = '[]' WHERE availability IS NULL;

SET SQL_SAFE_UPDATES = 1;

CREATE TABLE doctor_availability (
    availability_id INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id INT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON DELETE CASCADE
);


ALTER TABLE doctors DROP COLUMN availability;

ALTER TABLE doctor_availability ADD CONSTRAINT unique_doctor_date_time UNIQUE (doctor_id, date, time);
SELECT doctor_id, date, time, COUNT(*)
FROM doctor_availability
GROUP BY doctor_id, date, time
HAVING COUNT(*) > 1;

DELETE FROM doctor_availability
WHERE availability_id NOT IN (
    SELECT MIN(availability_id)
    FROM (SELECT * FROM doctor_availability) AS temp
    GROUP BY doctor_id, date, time
);
DELETE doctor_availability
FROM doctor_availability
JOIN (
    SELECT doctor_id, date, time, MIN(availability_id) AS min_id
    FROM doctor_availability
    GROUP BY doctor_id, date, time
) AS duplicates ON doctor_availability.doctor_id = duplicates.doctor_id
    AND doctor_availability.date = duplicates.date
    AND doctor_availability.time = duplicates.time
    AND doctor_availability.availability_id != duplicates.min_id;
SET SQL_SAFE_UPDATES = 0;

DELETE FROM doctor_availability
WHERE availability_id NOT IN (
    SELECT MIN(availability_id)
    FROM (SELECT * FROM doctor_availability) AS temp
    GROUP BY doctor_id, date, time
);

SET SQL_SAFE_UPDATES = 1;

SET SQL_SAFE_UPDATES = 0;
ALTER TABLE doctor_availability
ADD CONSTRAINT unique_doctor_date_time UNIQUE (doctor_id, date, time);

ALTER TABLE doctor_availability
ADD COLUMN is_booked BOOLEAN DEFAULT FALSE;

SHOW VARIABLES LIKE 'wait_timeout';
SHOW VARIABLES LIKE 'interactive_timeout';

ALTER TABLE doctor_availability
ADD COLUMN is_booked BOOLEAN DEFAULT FALSE;
SELECT COUNT(*) FROM doctor_availability;


ALTER TABLE users ADD COLUMN profile_picture VARCHAR(255);



UPDATE users SET profile_picture = 'default_profile.png' WHERE profile_picture IS NULL;


SELECT * 
FROM doctor_availability
WHERE date > CURDATE() 
   OR (date = CURDATE() AND time >= CURTIME());
SELECT availability_id, doctor_id, date, time
FROM doctor_availability
WHERE date > CURDATE()
   OR (date = CURDATE() AND time >= CURTIME());
SELECT availability_id, doctor_id, date, time
FROM doctor_availability
WHERE date > CURDATE()
   OR (date = CURDATE() AND time >= CURTIME());
   
SELECT CURDATE(), CURTIME();

SELECT availability_id, doctor_id, date, time
FROM doctor_availability
ORDER BY date, time;

SELECT availability_id, doctor_id, date, time
FROM doctor_availability
WHERE (date > CURDATE())  -- Future dates
   OR (date = CURDATE() AND time >= CURTIME())  -- Today with valid times
ORDER BY date, time;


