import customtkinter as ctk
from tkinter import messagebox
import sys
from config import connect_db

# Retrieve `user_id` passed as a command-line argument
try:
    current_user_id = int(sys.argv[1])
except (IndexError, ValueError):
    messagebox.showerror("Error", "User ID not provided. Please log in again.")
    sys.exit(1)

# Function to fetch appointments for the doctor
def get_doctor_appointments(doctor_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT 
            a.appointment_id,
            CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
            a.appointment_date,
            a.status
        FROM appointments a
        JOIN users p ON a.patient_id = p.user_id
        WHERE a.doctor_id = %s AND a.status NOT IN ('canceled', 'completed')
        ORDER BY a.appointment_date DESC
    """, (doctor_id,))
    appointments = cursor.fetchall()
    conn.close()
    return appointments

# Function to cancel an appointment
def cancel_appointment(appointment_id, root):
    response = messagebox.askyesno(
        "Confirm Cancellation",
        "Are you sure you want to cancel this appointment?"
    )
    if response:
        try:
            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute("UPDATE appointments SET status = 'canceled' WHERE appointment_id = %s", (appointment_id,))
            conn.commit()
            conn.close()
            root.destroy()
            messagebox.showinfo("Success", "Appointment has been canceled successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to cancel appointment: {e}")

# Main function for the cancel appointment window
def cancel_appointments_window():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT doctor_id FROM doctors WHERE user_id = %s", (current_user_id,))
    doctor_id_result = cursor.fetchone()
    conn.close()

    if not doctor_id_result:
        messagebox.showerror("Error", "Doctor record not found.")
        return

    doctor_id = doctor_id_result[0]
    appointments = get_doctor_appointments(doctor_id)

    root = ctk.CTk()
    root.title("Cancel Appointments")
    root.geometry("700x500")
    root.configure(fg_color="#c0d9f0")

    title_label = ctk.CTkLabel(
        root,
        text="Cancel Appointments",
        font=("Helvetica", 20, "bold"),
        text_color="#001f4d"
    )
    title_label.pack(pady=20)

    if appointments:
        for appointment in appointments:
            appointment_id, patient_name, appointment_date, status = appointment
            appointment_frame = ctk.CTkFrame(root, fg_color="white", corner_radius=10)
            appointment_frame.pack(fill="x", padx=20, pady=10)

            appointment_info = (
                f"Patient Name: {patient_name}\n"
                f"Date: {appointment_date}\n"
                f"Status: {status}"
            )
            info_label = ctk.CTkLabel(
                appointment_frame,
                text=appointment_info,
                font=("Arial", 14),
                text_color="#333333",
                justify="left"
            )
            info_label.pack(side="left", padx=10)

            cancel_button = ctk.CTkButton(
                appointment_frame,
                text="Cancel",
                fg_color="#ff3300",
                text_color="white",
                command=lambda appt_id=appointment_id: cancel_appointment(appt_id, root)
            )
            cancel_button.pack(side="right", padx=10, pady=10)
    else:
        no_appointments_label = ctk.CTkLabel(
            root,
            text="No active appointments to cancel.",
            font=("Arial", 14),
            text_color="#666666"
        )
        no_appointments_label.pack(pady=20)

    root.mainloop()

# Run the Cancel Appointments Window
if __name__ == "__main__":
    cancel_appointments_window()
