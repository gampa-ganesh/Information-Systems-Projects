import tkinter as tk
import customtkinter as ctk
from tkinter import messagebox
from PIL import Image, ImageTk
import re
from datetime import datetime
import subprocess
from config import connect_db  # Import the database connection
import bcrypt  # For password hashing
import sys  # Import sys to use sys.executable for Python path
import os  # Import os for path checking

# Initialize the main window
root = ctk.CTk()
root.title("Sign Up for DocLink")
root.geometry("750x750")
root.configure(fg_color="#001f4d")  # Background color for the main window

# Path to the login page
LOGIN_PAGE_PATH = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\signin.py"

# Header for Signup Page
header_label = ctk.CTkLabel(root, text="Create Your DocLink Account", font=("Verdana", 28, "bold"), text_color="#ffffff")
header_label.place(relx=0.5, rely=0.06, anchor="center")

# Form Frame
form_frame = ctk.CTkFrame(root, width=600, height=600, corner_radius=10, fg_color="white")
form_frame.place(relx=0.5, rely=0.5, anchor="center")

# Function to display error message above the field label
def show_error(label, message):
    label.configure(text=message, text_color="red")

# Function to clear error messages
def clear_errors():
    for label in error_labels.values():
        label.configure(text="")

# Toggle password visibility
def toggle_password_visibility():
    show = "" if show_password_var.get() else "*"
    password_entry.configure(show=show)
    confirm_password_entry.configure(show=show)

# Function to open the login page
def open_login_page():
    try:
        if os.path.exists(LOGIN_PAGE_PATH):
            subprocess.Popen([sys.executable, LOGIN_PAGE_PATH], shell=True)
            root.destroy()  # Close the current window
        else:
            messagebox.showerror("Error", f"Login page not found at {LOGIN_PAGE_PATH}")
    except Exception as e:
        messagebox.showerror("Error", f"Could not open login page: {e}")

# Function to register the user in the database
def register_user(first_name, last_name, dob, role, address, email, password):
    conn = connect_db()
    cursor = conn.cursor()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())  # Hash the password

    query = """
    INSERT INTO users (first_name, last_name, date_of_birth, role, address, email, password)
    VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    data = (first_name, last_name, dob, role, address, email, hashed_password)

    try:
        cursor.execute(query, data)
        conn.commit()
        messagebox.showinfo("Success", "User registered successfully!")
        open_login_page()  # Redirect to login page upon successful signup
    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

# Initialize field error labels dictionary
error_labels = {}

# Field Labels, Entries, and Error Labels
error_labels["first_name"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["first_name"].place(relx=0.37, rely=0.06, anchor="center")
error_labels["last_name"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["last_name"].place(relx=0.65, rely=0.06, anchor="center")

ctk.CTkLabel(form_frame, text="Full Name", font=("Arial", 14, "bold"), text_color="#011557").place(relx=0.1, rely=0.1, anchor="w")
first_name_entry = ctk.CTkEntry(form_frame, width=150, placeholder_text="First Name")
first_name_entry.place(relx=0.38, rely=0.1, anchor="center")
last_name_entry = ctk.CTkEntry(form_frame, width=150, placeholder_text="Last Name")
last_name_entry.place(relx=0.65, rely=0.099, anchor="center")

# Date of Birth
error_labels["dob"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["dob"].place(relx=0.5, rely=0.16, anchor="center")

ctk.CTkLabel(form_frame, text="Date of Birth", font=("Arial", 14, "bold"), text_color="#011557").place(relx=0.1, rely=0.2, anchor="w")
dob_entry = ctk.CTkEntry(form_frame, width=300, placeholder_text="YYYY-MM-DD")
dob_entry.place(relx=0.5, rely=0.2, anchor="center")

# Email
error_labels["email"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["email"].place(relx=0.5, rely=0.26, anchor="center")

ctk.CTkLabel(form_frame, text="Email", font=("Arial", 14, "bold"), text_color="#011557").place(relx=0.1, rely=0.3, anchor="w")
email_entry = ctk.CTkEntry(form_frame, width=300, placeholder_text="e.g., example@domain.com")
email_entry.place(relx=0.5, rely=0.3, anchor="center")

# Password
error_labels["password"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["password"].place(relx=0.5, rely=0.36, anchor="center")

ctk.CTkLabel(form_frame, text="Password", font=("Arial", 14, "bold"), text_color="#011557").place(relx=0.1, rely=0.4, anchor="w")
password_entry = ctk.CTkEntry(form_frame, width=300, show="*", placeholder_text="8+ characters, mixed case")
password_entry.place(relx=0.5, rely=0.4, anchor="center")

# Confirm Password
error_labels["confirm_password"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["confirm_password"].place(relx=0.5, rely=0.47, anchor="center")

ctk.CTkLabel(form_frame, text="Confirm Password", font=("Arial", 14, "bold"), text_color="#011557").place(relx=0.1, rely=0.47, anchor="w")
confirm_password_entry = ctk.CTkEntry(form_frame, width=300, show="*", placeholder_text="Re-enter Password")
confirm_password_entry.place(relx=0.5, rely=0.52, anchor="center")

# Show Password Checkbox using tkinter instead of customtkinter
show_password_var = tk.BooleanVar()
show_password_checkbox = tk.Checkbutton(
    form_frame, text="Show Password", variable=show_password_var,
    command=toggle_password_visibility, font=("Arial", 10),
    bg="white", activebackground="white"
)
show_password_checkbox.place(relx=0.65, rely=0.57, anchor="center")

# Role Selection
error_labels["role"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["role"].place(relx=0.4, rely=0.62, anchor="center")

ctk.CTkLabel(form_frame, text="Role", font=("Arial", 14, "bold"), text_color="#001f4d").place(relx=0.1, rely=0.62, anchor="w")
role_var = tk.StringVar(value="Patient")
role_option_menu = ctk.CTkOptionMenu(form_frame, variable=role_var, values=["Patient", "Doctor"])
role_option_menu.place(relx=0.4, rely=0.62, anchor="center")

# Address Fields (Street, City, State, Zip)
error_labels["street"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["street"].place(relx=0.5, rely=0.68, anchor="center")

address_label = ctk.CTkLabel(form_frame, text="Address", font=("Arial", 14, "bold"), text_color="#011557")
address_label.place(relx=0.1, rely=0.72, anchor="w")
street_entry = ctk.CTkEntry(form_frame, width=300, placeholder_text="Street Address")
street_entry.place(relx=0.5, rely=0.72, anchor="center")

error_labels["city"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["city"].place(relx=0.28, rely=0.77, anchor="center")
error_labels["state"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["state"].place(relx=0.52, rely=0.77, anchor="center")
error_labels["zip"] = ctk.CTkLabel(form_frame, text="", font=("Arial", 10))
error_labels["zip"].place(relx=0.76, rely=0.77, anchor="center")

city_entry = ctk.CTkEntry(form_frame, width=140, placeholder_text="City")
city_entry.place(relx=0.28, rely=0.82, anchor="center")
state_entry = ctk.CTkEntry(form_frame, width=140, placeholder_text="State")
state_entry.place(relx=0.52, rely=0.82, anchor="center")
zip_entry = ctk.CTkEntry(form_frame, width=140, placeholder_text="Zip Code")
zip_entry.place(relx=0.76, rely=0.82, anchor="center")

# Validation Functions
def is_valid_name(name):
    return bool(re.match("^[A-Za-z]{1,30}$", name))

def is_valid_email(email):
    email_regex = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return re.match(email_regex, email)

def is_valid_password(password):
    return len(password) >= 8 and re.search(r"[A-Z]", password) and re.search(r"[a-z]", password) and re.search(r"\d", password)

def is_valid_zip(zip_code):
    return bool(re.match("^[A-Za-z0-9]{3,10}$", zip_code))

# Form Submission with Validation and Address Concatenation
def submit_form():
    first_name = first_name_entry.get()
    last_name = last_name_entry.get()
    dob = dob_entry.get()
    email = email_entry.get()
    password = password_entry.get()
    confirm_password = confirm_password_entry.get()
    street = street_entry.get()
    city = city_entry.get()
    state = state_entry.get()
    zip_code = zip_entry.get()
    role = role_var.get()

    # Concatenate the address fields
    address = f"{street}, {city}, {state}, {zip_code}"

    # Clear previous errors
    clear_errors()

    # Validation checks
    if not is_valid_name(first_name):
        show_error(error_labels["first_name"], "Invalid first name.")
    if not is_valid_name(last_name):
        show_error(error_labels["last_name"], "Invalid last name.")
    try:
        datetime.strptime(dob, "%Y-%m-%d")
    except ValueError:
        show_error(error_labels["dob"], "Invalid date format.")
    if not is_valid_email(email):
        show_error(error_labels["email"], "Invalid email format.")
    if not is_valid_password(password):
        show_error(error_labels["password"], "Password needs 8+ chars, mixed case, number.")
    if password != confirm_password:
        show_error(error_labels["confirm_password"], "Passwords do not match.")
    if role == "":
        show_error(error_labels["role"], "Role is required.")
    if not street:
        show_error(error_labels["street"], "Street address is required.")
    if not city:
        show_error(error_labels["city"], "City is required.")
    if not state:
        show_error(error_labels["state"], "State is required.")
    if not is_valid_zip(zip_code):
        show_error(error_labels["zip"], "Invalid zip code format.")

    # Check if there are any displayed errors
    if all(label.cget("text") == "" for label in error_labels.values()):
        # Register the user in the database
        register_user(first_name, last_name, dob, role, address, email, password)

# Sign Up Button
sign_up_button = ctk.CTkButton(form_frame, text="Sign Up", width=300, font=("Arial", 15, "bold"), fg_color="#001f4d", text_color="white", command=submit_form)
sign_up_button.place(relx=0.5, rely=0.9, anchor="center")

# Link to Login Page within form_frame
login_link = ctk.CTkLabel(form_frame, text="Already have an account? Log in here.", font=("Arial", 12), text_color="#007bff", cursor="hand2")
login_link.place(relx=0.5, rely=0.95, anchor="center")
login_link.bind("<Button-1>", lambda e: open_login_page())

root.mainloop()
