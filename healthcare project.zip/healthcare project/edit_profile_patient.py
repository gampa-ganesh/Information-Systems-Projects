import customtkinter as ctk
from tkcalendar import DateEntry
from tkinter import messagebox
from config import connect_db

# Function to update user data in the database
def update_user_data(user_id, first_name, last_name, email, phone_number, address, gender, date_of_birth):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE users
        SET first_name = %s, last_name = %s, email = %s, phone_number = %s, address = %s, gender = %s, date_of_birth = %s
        WHERE user_id = %s
    """, (first_name, last_name, email, phone_number, address, gender, date_of_birth, user_id))
    conn.commit()
    conn.close()

# Profile Editing Window using CustomTkinter
def open_profile_editor(root, current_user_id, refresh_dashboard):
    editor = ctk.CTkToplevel(root)
    editor.title("Edit Profile")
    editor.geometry("500x700")
    editor.configure(fg_color="#1a2e49")

    # Fetch current user data from the database
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT first_name, last_name, email, phone_number, address, gender, date_of_birth FROM users WHERE user_id = %s", (current_user_id,))
    user_data = cursor.fetchone()
    conn.close()

    # Variables for form fields
    first_name_var = ctk.StringVar(value=user_data[0])
    last_name_var = ctk.StringVar(value=user_data[1])
    email_var = ctk.StringVar(value=user_data[2])
    phone_var = ctk.StringVar(value=user_data[3])
    address_var = ctk.StringVar(value=user_data[4])
    gender_var = ctk.StringVar(value=user_data[5])

    # Form Layout
    ctk.CTkLabel(editor, text="First Name", text_color="white").pack(anchor="w", padx=20, pady=5)
    first_name_entry = ctk.CTkEntry(editor, textvariable=first_name_var, width=400)
    first_name_entry.pack(pady=5, padx=20)

    ctk.CTkLabel(editor, text="Last Name", text_color="white").pack(anchor="w", padx=20, pady=5)
    last_name_entry = ctk.CTkEntry(editor, textvariable=last_name_var, width=400)
    last_name_entry.pack(pady=5, padx=20)

    ctk.CTkLabel(editor, text="Email", text_color="white").pack(anchor="w", padx=20, pady=5)
    email_entry = ctk.CTkEntry(editor, textvariable=email_var, width=400)
    email_entry.pack(pady=5, padx=20)

    ctk.CTkLabel(editor, text="Phone Number", text_color="white").pack(anchor="w", padx=20, pady=5)
    phone_entry = ctk.CTkEntry(editor, textvariable=phone_var, width=400)
    phone_entry.pack(pady=5, padx=20)

    ctk.CTkLabel(editor, text="Address", text_color="white").pack(anchor="w", padx=20, pady=5)
    address_entry = ctk.CTkEntry(editor, textvariable=address_var, width=400)
    address_entry.pack(pady=5, padx=20)

    ctk.CTkLabel(editor, text="Gender", text_color="white").pack(anchor="w", padx=20, pady=5)
    gender_dropdown = ctk.CTkOptionMenu(editor, variable=gender_var, values=["Male", "Female", "Other"])
    gender_dropdown.pack(pady=5, padx=20)

    ctk.CTkLabel(editor, text="Date of Birth", text_color="white").pack(anchor="w", padx=20, pady=5)
    dob_entry = DateEntry(editor, width=18, background="darkblue", foreground="white", date_pattern='yyyy-mm-dd')
    dob_entry.set_date(user_data[6] if user_data[6] else "2000-01-01")
    dob_entry.pack(pady=5, padx=20)

    # Save button to update user data
    def save_profile_changes():
        update_user_data(
            current_user_id,
            first_name_var.get(),
            last_name_var.get(),
            email_var.get(),
            phone_var.get(),
            address_var.get(),
            gender_var.get(),
            dob_entry.get_date()
        )
        refresh_dashboard()
        editor.destroy()
        messagebox.showinfo("Profile Updated", "Your profile has been updated successfully.")

    save_button = ctk.CTkButton(editor, text="Save Changes", command=save_profile_changes, fg_color="#0072ff", text_color="white", width=400)
    save_button.pack(pady=20, padx=20)
