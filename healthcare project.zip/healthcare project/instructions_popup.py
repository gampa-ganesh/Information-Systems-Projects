import tkinter as tk
import customtkinter as ctk
from PIL import Image, ImageTk

# Function to open the instructions popup
def open_instructions_window(parent_window):
    # Define the instructions with specific headers and their descriptions
    instructions = [
        {
            "header": "Sign Up",
            "text": (
                "\u2022 Create your account on DocLink by filling in the required details.\n\n"
                "\u2022 Choose your role as either a Doctor or a Patient to personalize your experience."
            )
        },
        {
            "header": "Log In",
            "text": (
                "\u2022 Access your DocLink Dashboard by entering your credentials.\n\n"
                "\u2022 Explore features available for your selected role."
            )
        },
        {
            "header": "Edit Your Profile",
            "text": (
                "\u2022 Update your personal information in the Profile Section.\n\n"
                "\u2022 Completing your profile is mandatory before adding availability (for doctors) or booking appointments (for patients)."
            )
        },
        {
            "header": "For Doctors",
            "text": (
                "\u2022 Manage your schedule seamlessly by adding or canceling availability.\n\n"
                "\u2022 Doctors can also cancel appointments directly from the dashboard."
            )
        },
        {
            "header": "For Patients",
            "text": (
                "\u2022 Book or cancel appointments with ease.\n\n"
                "\u2022 Search for doctors by availability and book appointments that fit your schedule."
            )
        },
        {
            "header": "View Appointment History",
            "text": (
                "\u2022 Check your Appointment History to see details of past and upcoming appointments.\n\n"
                "\u2022 Track cancellations, whether initiated by you or the doctor."
            )
        }
    ]

    # Corresponding image paths for each instruction
    image_paths = [
        r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\picture\signup.jpg",
        r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\picture\signin.jpg",
        r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\picture\update profile.jpg",
        r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\picture\doctor avalability.jpg",
        r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\picture\appointment booking.jpg",
        r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\picture\notifiy.jpg"
    ]

    # Track the current step
    current_step = [0]

    # Create the Toplevel window
    instructions_window = ctk.CTkToplevel(parent_window)
    instructions_window.title("How to Use DocLink")
    instructions_window.geometry("1050x500")
    instructions_window.configure(fg_color="#abd0d9")  # Set the main background color

    # Bring the popup to the front and ensure it stays on top
    instructions_window.lift()
    instructions_window.attributes("-topmost", True)
    instructions_window.focus_force()

    # Instructions and Image Frames
    content_frame = ctk.CTkFrame(instructions_window, fg_color="#abd0d9")
    content_frame.pack(fill="both", expand=True, padx=30, pady=20)

    # Left Side: Instructions
    instructions_frame = ctk.CTkFrame(content_frame, fg_color="#abd0d9", corner_radius=20)
    instructions_frame.grid(row=0, column=0, padx=20, pady=10, sticky="nsew")

    header_label = ctk.CTkLabel(
        instructions_frame,
        text=instructions[current_step[0]]["header"],  # Display the first instruction header
        font=("Verdana", 35, "bold"),
        text_color="#000e47"
    )
    header_label.pack(pady=10)

    instructions_label = ctk.CTkLabel(
        instructions_frame,
        text=instructions[current_step[0]]["text"],  # Display the first instruction text with bullet points
        font=("Arial", 20, "bold"),
        text_color="#472201",
        justify="left",
        wraplength=400,
        fg_color="#abd0d9"
    )
    instructions_label.pack(pady=10, padx=20)

    # Right Side: Image with Border
    right_image_frame = ctk.CTkFrame(content_frame, fg_color="#abd0d9", corner_radius=20)
    right_image_frame.grid(row=0, column=1, padx=20, pady=10, sticky="nsew")

    # Create a bordered frame for the image
    border_frame = ctk.CTkFrame(right_image_frame, fg_color="#001f4d", corner_radius=1, border_width=20, border_color="#ffffff")
    border_frame.pack(pady=10, padx=10)

    # Load and display the initial image inside the border
    right_image = Image.open(image_paths[current_step[0]]).resize((400, 400), Image.LANCZOS)
    right_photo = ImageTk.PhotoImage(right_image)

    right_image_label = tk.Label(border_frame, image=right_photo, bg="#001f4d")
    right_image_label.image = right_photo  # Keep reference to avoid garbage collection
    right_image_label.pack(pady=5, padx=5)

    # Buttons Section
    button_frame = ctk.CTkFrame(content_frame, fg_color="#abd0d9")
    button_frame.grid(row=1, column=0, columnspan=2, pady=20)

    # Function to update the content
    def update_content():
        header_label.configure(text=instructions[current_step[0]]["header"])
        instructions_label.configure(text=instructions[current_step[0]]["text"])
        new_image = Image.open(image_paths[current_step[0]]).resize((400, 400), Image.LANCZOS)
        new_photo = ImageTk.PhotoImage(new_image)
        right_image_label.configure(image=new_photo)
        right_image_label.image = new_photo

    # Function to go to the next step
    def next_step():
        if current_step[0] < len(instructions) - 1:
            current_step[0] += 1
            update_content()

    # Function to go to the previous step
    def previous_step():
        if current_step[0] > 0:
            current_step[0] -= 1
            update_content()

    # Navigation Buttons
    previous_button = ctk.CTkButton(
        button_frame,
        text="Previous",
        width=100,
        font=("Arial", 14, "bold"),
        fg_color="#001f4d",
        text_color="white",
        corner_radius=20,
        command=previous_step,
    )
    previous_button.pack(side="left", padx=20)

    next_button = ctk.CTkButton(
        button_frame,
        text="Next",
        width=100,
        font=("Arial", 14, "bold"),
        fg_color="#001f4d",
        text_color="white",
        corner_radius=20,
        command=next_step,
    )
    next_button.pack(side="right", padx=20)

    # Close Button
    close_button = ctk.CTkButton(
        button_frame,
        text="Close",
        width=120,
        font=("Arial", 14, "bold"),
        fg_color="#001f4d",
        text_color="white",
        corner_radius=20,
        command=instructions_window.destroy,
    )
    close_button.pack(side="bottom", pady=10)

    # Configure grid layout
    content_frame.grid_columnconfigure(0, weight=1)
    content_frame.grid_columnconfigure(1, weight=1)
