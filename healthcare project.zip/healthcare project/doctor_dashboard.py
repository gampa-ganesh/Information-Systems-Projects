import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox
from tkcalendar import DateEntry
from PIL import Image, ImageTk, ImageOps
from config import connect_db
import sys
import subprocess

# Define paths
DEFAULT_PROFILE_PICTURE_PATH = "C:\\Users\\gampa2g\\PycharmProjects\\pythonProject\\healthcare project\\picture\\doctor_icon.png"
HOME_PAGE_PATH = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\home.py"

# Initialize the main window with theme customization
root = ctk.CTk()
root.title("DocLink - Doctor Dashboard")
root.geometry("1200x600")
root.configure(fg_color="#8ea1bf")

# Apply a custom theme
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# Retrieve `user_id` passed as a command-line argument
try:
    current_user_id = int(sys.argv[1])
except (IndexError, ValueError):
    messagebox.showerror("Error", "User ID not provided. Please log in again.")
    sys.exit(1)

# Functions to retrieve and update user data
def get_user_data(user_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT u.first_name, u.last_name, u.email, u.phone_number, u.gender, u.date_of_birth,
               d.specialization, d.clinic_address
        FROM users u
        LEFT JOIN doctors d ON u.user_id = d.user_id
        WHERE u.user_id = %s
    """, (user_id,))
    user_data = cursor.fetchone()
    conn.close()
    return user_data

# Helper function to parse clinic_address into components
def parse_address(address):
    if not address:
        return "", "", "", ""
    parts = address.split(", ")
    return (parts + [""] * 4)[:4]  # Ensure we return four parts

def update_user_data(user_id, first_name, last_name, email, phone_number, gender, date_of_birth, specialization,
                     clinic_address):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE users
        SET first_name = %s, last_name = %s, email = %s, phone_number = %s, gender = %s, date_of_birth = %s
        WHERE user_id = %s
    """, (first_name, last_name, email, phone_number, gender, date_of_birth, user_id))

    cursor.execute("SELECT 1 FROM doctors WHERE user_id = %s", (user_id,))
    if cursor.fetchone():
        cursor.execute("""
            UPDATE doctors
            SET specialization = %s, clinic_address = %s
            WHERE user_id = %s
        """, (specialization, clinic_address, user_id))
    else:
        cursor.execute("""
            INSERT INTO doctors (user_id, specialization, clinic_address)
            VALUES (%s, %s, %s)
        """, (user_id, specialization, clinic_address))

    conn.commit()
    conn.close()

# Header with welcome message, profile link, and sign-out link
header_frame = ctk.CTkFrame(root, fg_color="#001f4d", height=70)
header_frame.pack(fill="x", padx=20, pady=10)
header_frame.pack_propagate(False)  # Disable auto-resizing of the header frame

# Display welcome message with the user's first name
user_data = get_user_data(current_user_id)
first_name, last_name, email, phone_number, gender, date_of_birth, specialization, clinic_address = user_data if user_data else (
"Doctor", "", "", "", "", "", "", "")
welcome_message = f"Hello Dr. {first_name}, Welcome to DocLink"
welcome_label = ctk.CTkLabel(header_frame, text=welcome_message, font=("Helvetica", 23, "bold"), text_color="#ffffff")
welcome_label.pack(side="left", padx=20)

# Navigation links: Profile and Sign Out
signout_link = ctk.CTkLabel(header_frame, text="Sign Out", font=("Arial", 15, "bold", "underline"),
                            text_color="#ffffff", cursor="hand2")
signout_link.pack(side="right", padx=20)
signout_link.bind("<Button-1>", lambda e: sign_out())  # Link to sign-out function


profile_link = ctk.CTkLabel(header_frame, text="Edit Profile", font=("Arial", 15, "bold", "underline"),
                            text_color="#ffffff", cursor="hand2")
profile_link.pack(side="right", padx=20)
profile_link.bind("<Button-1>", lambda e: open_profile_editor())  # Link to profile editor
import os
import subprocess
from tkinter import messagebox
from generate_reports import generate_completed_appointments_report

reports_link = ctk.CTkLabel(header_frame, text="Get Reports", font=("Arial", 15, "bold", "underline"),
                            text_color="#ffffff", cursor="hand2")
reports_link.pack(side="right", padx=20)
reports_link.bind(
    "<Button-1>",
    lambda e: generate_completed_appointments_report(current_user_id, first_name, last_name)
)

def open_generate_reports():
    """
    Opens the generate_reports.py file as a subprocess.
    """
    try:
        # File path to the reports script
        reports_script_path = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\generate_reports.py"

        # Debug: Check if the file exists
        if not os.path.exists(reports_script_path):
            messagebox.showerror("Error", f"File not found: {reports_script_path}")
            return

        # Run the script with the current_user_id
        subprocess.run(["python", reports_script_path, str(current_user_id)], shell=True)
        messagebox.showinfo("Success", "Report generation initiated.")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to generate reports: {e}")



# Function to handle sign-out
def sign_out():
    root.destroy()  # Close the main window
    try:
        subprocess.run([sys.executable, HOME_PAGE_PATH])  # Open the home page script
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open the home page: {e}")

# Function to open profile editor
def open_profile_editor():
    editor = ctk.CTkToplevel(root)
    editor.title("Edit Profile")
    editor.geometry("595x650")
    editor.configure(fg_color="#1a2e49")
    editor.grab_set()
    editor.focus_set()

    # Parse clinic address into components
    street, city, state, zip_code = parse_address(clinic_address)

    # Variables for fields
    first_name_var = ctk.StringVar(value=first_name)
    last_name_var = ctk.StringVar(value=last_name)
    email_var = ctk.StringVar(value=email)
    phone_number_var = ctk.StringVar(value=phone_number)
    gender_var = ctk.StringVar(value=gender)
    date_of_birth_var = ctk.StringVar(value=date_of_birth)
    specialization_var = ctk.StringVar(value=specialization)
    street_var = ctk.StringVar(value=street)
    city_var = ctk.StringVar(value=city)
    state_var = ctk.StringVar(value=state)
    zip_code_var = ctk.StringVar(value=zip_code)

    # Title
    title_label = ctk.CTkLabel(editor, text="Edit Your Profile", font=("Helvetica", 30, "bold"), text_color="white")
    title_label.pack(pady=10)

    # Function to add labels and entry fields
    def create_label_and_entry(label_text, text_var, width=300):
        label = ctk.CTkLabel(editor, text=label_text, font=("Arial", 15,"bold"), text_color="white")
        label.pack(anchor="w", padx=30)
        entry = ctk.CTkEntry(editor, textvariable=text_var, width=width)
        entry.pack(pady=5, padx=30)

    # Name fields in a row
    name_frame = ctk.CTkFrame(editor, fg_color="#1a2e49")
    name_frame.pack(pady=10, padx=30, fill="x")
    first_name_label = ctk.CTkLabel(name_frame, text="First Name", font=("Arial", 15, "bold"), text_color="white")
    first_name_label.grid(row=0, column=0, padx=5)
    first_name_entry = ctk.CTkEntry(name_frame, textvariable=first_name_var, width=150)
    first_name_entry.grid(row=0, column=1, padx=5)
    last_name_label = ctk.CTkLabel(name_frame, text="Last Name", font=("Arial", 15, "bold"), text_color="white")
    last_name_label.grid(row=0, column=2, padx=5)
    last_name_entry = ctk.CTkEntry(name_frame, textvariable=last_name_var, width=150)
    last_name_entry.grid(row=0, column=3, padx=5)

    # Email field
    create_label_and_entry("Email", email_var, width=350)

    # Phone Number field
    create_label_and_entry("Phone Number", phone_number_var, width=350)

    # Gender dropdown
    gender_label = ctk.CTkLabel(editor, text="Gender", font=("Arial", 15, "bold"), text_color="white")
    gender_label.pack(anchor="w", padx=30)
    gender_dropdown = ctk.CTkOptionMenu(editor, variable=gender_var, values=["Male", "Female", "Other"])
    gender_dropdown.pack(pady=5, padx=30)

    # Date of Birth
    dob_label = ctk.CTkLabel(editor, text="Date of Birth", font=("Arial", 15, "bold"), text_color="white")
    dob_label.pack(anchor="w", padx=30)
    dob_entry = DateEntry(editor, width=20, background="darkblue", foreground="white", date_pattern="yyyy-mm-dd")
    dob_entry.set_date(date_of_birth_var.get() if date_of_birth_var.get() else "2000-01-01")
    dob_entry.pack(pady=5, padx=30)

    # Specialization field
    create_label_and_entry("Specialization", specialization_var, width=350)

    # Address fields with grouping
    address_label = ctk.CTkLabel(editor, text="Clinic Address", font=("Arial", 15, "bold"), text_color="white")
    address_label.pack(anchor="w", padx=30, pady=(20, 5))

    # Grouped address fields
    address_frame = ctk.CTkFrame(editor, fg_color="#1a2e49")
    address_frame.pack(pady=10, padx=30, fill="x")

    street_label = ctk.CTkLabel(address_frame, text="Street", font=("Arial", 15, "bold"), text_color="white")
    street_label.grid(row=0, column=0, padx=5)
    street_entry = ctk.CTkEntry(address_frame, textvariable=street_var, width=300)
    street_entry.grid(row=0, column=1, padx=5, columnspan=3)

    city_label = ctk.CTkLabel(address_frame, text="City", font=("Arial", 15, "bold"), text_color="white")
    city_label.grid(row=4, column=0, padx=5)
    city_entry = ctk.CTkEntry(address_frame, textvariable=city_var, width=120)
    city_entry.grid(row=4, column=1, padx=5)

    state_label = ctk.CTkLabel(address_frame, text="State", font=("Arial", 15, "bold"), text_color="white")
    state_label.grid(row=4, column=2, padx=5)
    state_entry = ctk.CTkEntry(address_frame, textvariable=state_var, width=80)
    state_entry.grid(row=4, column=3, padx=5)

    zip_code_label = ctk.CTkLabel(address_frame, text="Zip Code", font=("Arial", 15, "bold"), text_color="white")
    zip_code_label.grid(row=6, column=0, padx=5)
    zip_code_entry = ctk.CTkEntry(address_frame, textvariable=zip_code_var, width=120)
    zip_code_entry.grid(row=6, column=1, padx=5)

    # Save button for profile editor
    def save_profile_changes():
        full_address = f"{street_var.get()}, {city_var.get()}, {state_var.get()}, {zip_code_var.get()}"
        update_user_data(
            current_user_id,
            first_name_var.get(),
            last_name_var.get(),
            email_var.get(),
            phone_number_var.get(),
            gender_var.get(),
            dob_entry.get_date(),
            specialization_var.get(),
            full_address
        )
        editor.destroy()
        messagebox.showinfo("Profile Updated", "Your profile has been updated successfully.")
        refresh_doctor_info()

    save_button = ctk.CTkButton(editor, text="Save Changes", command=save_profile_changes, fg_color="#0072ff",
                                text_color="white", width=250)
    save_button.pack(pady=20)

# Refresh doctor information after profile update
def refresh_doctor_info():
    user_data = get_user_data(current_user_id)
    if not user_data:
        return
    first_name, last_name, email, phone_number, gender, date_of_birth, specialization, clinic_address = user_data
    street, city, state, zip_code = parse_address(clinic_address)
    doctor_info_text = (f"Name: Dr. {first_name} {last_name}\n"
                        f"Email: {email}\nPhone Number: {phone_number}\nGender: {gender}\n"
                        f"Date of Birth: {date_of_birth}\nSpecialization: {specialization}\n"
                        f"Clinic Address:\n"
                        f"  Street: {street}\n"
                        f"  City: {city}\n"
                        f"  State: {state}\n"
                        f"  Zip Code: {zip_code}")
    doctor_info_content.configure(text=doctor_info_text)

# Initialize doctor info frame, profile picture, and user information
doctor_info_frame = ctk.CTkFrame(root, fg_color="white", width=360, height=100, corner_radius=10)
doctor_info_frame.pack(side="left", padx=20, pady=20, fill="both", expand=True)

doctor_info_label = ctk.CTkLabel(doctor_info_frame, text="Doctor Information", font=("Arial", 18, "bold"),
                                 text_color="#001f4d")
doctor_info_label.pack(anchor="w", padx=20, pady=10)

profile_picture_frame = tk.Frame(doctor_info_frame, bg="white")
profile_picture_frame.pack(side="top", anchor="ne", padx=20, pady=5)

try:
    profile_image = Image.open(DEFAULT_PROFILE_PICTURE_PATH)
    profile_image = profile_image.resize((165, 165), Image.LANCZOS)
    profile_image = ImageOps.fit(profile_image, (165, 165), Image.LANCZOS, centering=(0.6, 0.6))
    profile_image = ImageTk.PhotoImage(profile_image)
except Exception as e:
    messagebox.showerror("Error", f"Could not load profile picture: {e}")
    profile_image = None

if profile_image:
    profile_image_label = tk.Label(profile_picture_frame, image=profile_image, bg="white")
    profile_image_label.image = profile_image
    profile_image_label.pack()

doctor_info_content = ctk.CTkLabel(doctor_info_frame, text="", font=("Arial", 14), text_color="#666666", justify="left")
doctor_info_content.pack(anchor="w", padx=20, pady=(10, 30))
refresh_doctor_info()

# Remaining dashboard setup for availability management and history
availability_frame = ctk.CTkFrame(root, fg_color="white", width=360, height=300, corner_radius=10)
availability_frame.pack(side="left", padx=20, pady=20, fill="both", expand=True)

availability_label = ctk.CTkLabel(availability_frame, text="Manage Availability", font=("Arial", 18, "bold"),
                                  text_color="#333333")
availability_label.pack(anchor="w", padx=20, pady=10)


from datetime import datetime
from tkcalendar import DateEntry
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk

def open_add_availability():
    availability_window = ctk.CTkToplevel(root)
    availability_window.title("Add Availability")
    availability_window.geometry("450x400")
    availability_window.configure(fg_color="#1a2e49")
    availability_window.grab_set()
    availability_window.focus_set()

    reminder_label = ctk.CTkLabel(
        availability_window,
        text="NOTE: Please ensure your profile (phone number and clinic address) is up-to-date\nbefore adding availability.",
        font=("Arial", 15, "italic", "bold"),
        text_color="red",
        wraplength=400,
        justify="center"
    )
    reminder_label.pack(pady=10)

    date_label = ctk.CTkLabel(availability_window, text="Select Date", font=("Arial", 14, "bold"), text_color="white")
    date_label.pack(pady=10)
    date_entry = DateEntry(
        availability_window,
        width=18,
        background="darkblue",
        foreground="white",
        date_pattern="yyyy-MM-dd",
        mindate=datetime.now().date()  # Prevent past dates
    )
    date_entry.pack(pady=5)

    time_label = ctk.CTkLabel(availability_window, text="Select Time (HH:MM AM/PM)", font=("Arial", 14, "bold"),
                              text_color="white")
    time_label.pack(pady=10)

    time_frame = ctk.CTkFrame(availability_window, fg_color="#1a2e49")
    time_frame.pack(pady=5, padx=30, fill="x")

    hour_var = tk.StringVar(value="08")
    minute_var = tk.StringVar(value="00")
    period_var = tk.StringVar(value="AM")

    hour_entry = ctk.CTkEntry(time_frame, textvariable=hour_var, width=50)
    hour_entry.grid(row=0, column=0, padx=5)
    colon_label = ctk.CTkLabel(time_frame, text=":", font=("Arial", 14, "bold"), text_color="white")
    colon_label.grid(row=0, column=1, padx=2)
    minute_entry = ctk.CTkEntry(time_frame, textvariable=minute_var, width=50)
    minute_entry.grid(row=0, column=2, padx=5)
    period_dropdown = ctk.CTkOptionMenu(time_frame, variable=period_var, values=["AM", "PM"])
    period_dropdown.grid(row=0, column=3, padx=5)

    format_label = ctk.CTkLabel(availability_window, text="(12-hour format)", font=("Arial", 13, "italic"),
                                text_color="white")
    format_label.pack(pady=(5, 10), anchor="center")

    def save_availability():
        # Fetch the selected date and time
        date = date_entry.get()
        hour = int(hour_var.get())
        minute = int(minute_var.get())
        period = period_var.get()

        # Convert to 24-hour format
        if period == "PM" and hour != 12:
            hour += 12
        elif period == "AM" and hour == 12:
            hour = 0
        time = f"{hour:02}:{minute:02}:00"

        # Combine date and time into a datetime object
        selected_datetime = datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M:%S")
        current_datetime = datetime.now()

        # Check if the selected date and time are in the past
        if selected_datetime < current_datetime:
            messagebox.showerror("Error", "Cannot add availability for a past date or time.")
            return

        # Connect to the database
        conn = connect_db()
        cursor = conn.cursor()

        # Check if the doctor exists
        cursor.execute("SELECT doctor_id FROM doctors WHERE user_id = %s", (current_user_id,))
        doctor_result = cursor.fetchone()
        if not doctor_result:
            messagebox.showerror("Error", "Doctor record does not exist. Please ensure the doctor is registered.")
            conn.close()
            return
        doctor_id = doctor_result[0]

        # Check if the availability already exists
        cursor.execute(
            "SELECT COUNT(*) FROM doctor_availability WHERE doctor_id = %s AND date = %s AND time = %s",
            (doctor_id, date, time)
        )
        if cursor.fetchone()[0] > 0:
            messagebox.showerror("Error", "This availability already exists.")
            conn.close()
            return

        # Insert the new availability
        cursor.execute(
            "INSERT INTO doctor_availability (doctor_id, date, time) VALUES (%s, %s, %s)",
            (doctor_id, date, time)
        )
        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Availability added successfully.")
        availability_window.destroy()

    save_button = ctk.CTkButton(
        availability_window,
        text="Save Availability",
        command=save_availability,
        fg_color="#0072ff",
        text_color="white",
        font=("Arial", 13, "bold"),
        width=200
    )
    save_button.pack(pady=20)

add_availability_button = ctk.CTkButton(
    availability_frame,
    text="Add Availability",
    command=open_add_availability,
    fg_color="#ff9900",
    text_color="white",
    font=("Arial", 13, "bold")
)
add_availability_button.pack(pady=10, padx=20)


# Function to cancel availability
def open_cancel_availability():
    try:
        # Create a new window for canceling availability
        cancel_window = ctk.CTkToplevel(root)
        cancel_window.title("Cancel Availability")
        cancel_window.geometry("450x450")
        cancel_window.configure(fg_color="#1a2e49")
        cancel_window.grab_set()
        cancel_window.focus_set()

        # Fetch doctor_id from the database based on current_user_id
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT doctor_id FROM doctors WHERE user_id = %s", (current_user_id,))
        doctor_result = cursor.fetchone()

        # Check if doctor record exists
        if not doctor_result:
            messagebox.showerror("Error", "Doctor record does not exist.")
            conn.close()
            return
        doctor_id = doctor_result[0]

        # Fetch all available slots for the doctor
        cursor.execute("SELECT availability_id, date, time FROM doctor_availability WHERE doctor_id = %s", (doctor_id,))
        availabilities = cursor.fetchall()
        conn.close()

        # Listbox to display the doctor's availabilities with multiple selection enabled
        availability_list = tk.Listbox(cancel_window, width=50, height=10, selectmode=tk.MULTIPLE)
        availability_list.pack(pady=10, padx=20)

        # Populate the Listbox with availability entries
        availability_dict = {}  # Dictionary to map display text to availability ID
        for availability in availabilities:
            availability_id, date, time = availability
            display_text = f"Date: {date} | Time: {time}"
            availability_list.insert(tk.END, display_text)
            availability_dict[display_text] = availability_id

        # Function to cancel the selected availabilities
        def cancel_selected_availabilities():
            selected_indices = availability_list.curselection()
            if not selected_indices:
                messagebox.showerror("Error", "No availability selected.")
                return

            # Collect the IDs of the selected availabilities
            selected_ids = [availability_dict[availability_list.get(i)] for i in selected_indices]

            # Delete the selected availabilities from the database
            try:
                conn = connect_db()
                cursor = conn.cursor()
                cursor.executemany("DELETE FROM doctor_availability WHERE availability_id = %s", [(availability_id,) for availability_id in selected_ids])
                conn.commit()
                conn.close()

                # Update the UI by removing canceled items from the listbox
                for i in reversed(selected_indices):
                    availability_list.delete(i)
                messagebox.showinfo("Success", "Selected availabilities cancelled successfully.")
            except Exception as e:
                messagebox.showerror("Database Error", f"An error occurred while canceling availabilities: {e}")

        # Cancel button to trigger the cancellation of selected availabilities
        cancel_button = ctk.CTkButton(
            cancel_window,
            text="Cancel Selected Availabilities",
            command=cancel_selected_availabilities,
            fg_color="#ff3300",
            text_color="white",
            font=("Arial", 13, "bold"),
            width=250
        )
        cancel_button.pack(pady=20)

    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {e}")


# Add the "Cancel Availability" button to open the cancellation window
cancel_availability_button = ctk.CTkButton(
    availability_frame,
    text="Cancel Availability",
    command=open_cancel_availability,  # Updated to open the cancellation window
    fg_color="#ff3300",
    text_color="white",
    font=("Arial", 13, "bold")
)
cancel_availability_button.pack(pady=10, padx=20)

import customtkinter as ctk
from tkinter import messagebox
import tkinter as tk
from config import connect_db  # Assuming you have a database connection function


# Function to get appointment details for the doctor
def get_doctor_appointments(doctor_id):
    conn = connect_db()
    cursor = conn.cursor()
    query = """
        SELECT 
            a.appointment_id,
            CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
            p.gender,
            p.date_of_birth,
            a.appointment_date,
            a.status
        FROM 
            appointments a
        JOIN 
            users p ON a.patient_id = p.user_id
        WHERE 
            a.doctor_id = %s
        ORDER BY 
            a.appointment_date DESC
    """
    cursor.execute(query, (doctor_id,))
    appointments = cursor.fetchall()
    conn.close()
    return appointments

def mark_appointment_as_completed(appointment_id):
    """
    Marks an appointment as completed for the given appointment ID.
    """
    try:
        conn = connect_db()
        cursor = conn.cursor()

        # Update the status to 'completed'
        query = """
            UPDATE appointments
            SET status = 'completed'
            WHERE appointment_id = %s;
        """
        cursor.execute(query, (appointment_id,))
        conn.commit()
        conn.close()

        # Success message
        messagebox.showinfo("Success", f"Appointment ID {appointment_id} marked as completed.")
        refresh_appointment_history()  # Refresh the appointment history
    except Exception as e:
        messagebox.showerror("Error", f"Failed to mark appointment as completed: {e}")



def refresh_appointment_history():
    """
    Refresh the appointment history frame in the doctor's dashboard.
    """
    # Clear current content in the scrollable frame
    for widget in scrollable_frame.winfo_children():
        widget.destroy()

    # Fetch doctor_id first
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT doctor_id FROM doctors WHERE user_id = %s", (current_user_id,))
    doctor_id_result = cursor.fetchone()
    conn.close()

    if not doctor_id_result:
        messagebox.showerror("Error", "Doctor record not found. Please ensure you are registered as a doctor.")
        return

    doctor_id = doctor_id_result[0]
    appointments = get_doctor_appointments(doctor_id)

    if appointments:
        for appointment in appointments:
            appointment_id, patient_name, gender, dob, appointment_date, status = appointment

            # Determine the color for the status
            if status.lower() == "canceled":
                status_color = "red"
            elif status.lower() == "booked":
                status_color = "dark blue"
            else:
                status_color = "green"  # Default color

            # Format the appointment text
            appointment_text = (
                f"Patient: {patient_name} (Gender: {gender}, DOB: {dob})\n"
                f"Date: {appointment_date}\n"
                f"Status: {status}"
            )

            # Create a label for the appointment, applying the status color
            appt_label = ctk.CTkLabel(
                scrollable_frame,
                text=appointment_text,
                font=("Arial", 12),
                text_color=status_color,
                justify="left"
            )
            appt_label.pack(anchor="w", padx=20, pady=5)

            # Add a "Mark as Completed" button for booked appointments
            if status.lower() == "booked":
                complete_button = ctk.CTkButton(
                    scrollable_frame,
                    text="Mark as Completed",
                    fg_color="#28A745",  # Green button
                    text_color="white",
                    command=lambda appt_id=appointment_id: mark_appointment_as_completed(appt_id)
                )
                complete_button.pack(anchor="e", padx=20, pady=5)
    else:
        no_appt_label = ctk.CTkLabel(
            scrollable_frame,
            text="No appointments found.",
            font=("Arial", 12),
            text_color="#666666"
        )
        no_appt_label.pack(anchor="w", padx=20, pady=10)

# Add an Appointment History section to the dashboard
appointment_history_frame = ctk.CTkFrame(root, fg_color="white", width=360, height=300, corner_radius=10)
appointment_history_frame.pack(side="left", padx=20, pady=20, fill="both", expand=True)

# Header frame for label and refresh button
header_frame = ctk.CTkFrame(appointment_history_frame, fg_color="white")
header_frame.pack(fill="x", padx=20, pady=10)

# Appointment History Label
appointment_history_label = ctk.CTkLabel(
    header_frame,
    text="Appointment History",
    font=("Arial", 18, "bold"),
    text_color="#333333"
)
appointment_history_label.pack(side="left")

# Refresh Button
refresh_button = ctk.CTkButton(
    header_frame,
    text="Refresh",
    font=("Arial", 13),
    command=refresh_appointment_history,
    corner_radius=5,
    fg_color="#007BFF",
    text_color="white",
    width=150
)
refresh_button.pack(side="right", padx=10)

# Add a Scrollable Frame for displaying appointments
canvas = tk.Canvas(appointment_history_frame, bg="white", highlightthickness=0)
scrollbar = tk.Scrollbar(appointment_history_frame, orient="vertical", command=canvas.yview)
scrollable_frame = ctk.CTkFrame(canvas, fg_color="white")

scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
)

canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)

canvas.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")

# Refresh the appointment history initially
refresh_appointment_history()


# Function to open the Cancel Appointment Window
def open_cancel_appointment_window():
    """
    Opens a new window for the doctor to cancel appointments.
    """
    try:
        # Path to the file where the cancel appointment logic for the doctor is defined
        cancel_appointment_path = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\cancel_appointment_doctor.py"

        # Execute the script with the current_user_id passed as an argument
        subprocess.run(["python", cancel_appointment_path, str(current_user_id)])
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open Cancel Appointment window: {e}")


# Add "Cancel Appointment" Button
cancel_appointment_button = ctk.CTkButton(
    availability_frame,
    text="Cancel Appointments",
    command=open_cancel_appointment_window,
    fg_color="#ff3300",
    text_color="white",
    font=("Arial", 13, "bold")
)
cancel_appointment_button.pack(pady=10, padx=20)

# Run the main loop
root.mainloop()
