import tkinter as tk
import customtkinter as ctk
from datetime import datetime
import os
import re
import bcrypt
from tkinter import messagebox
from config import connect_db
import sys

# Paths to the dashboards and pages
DOCTOR_DASHBOARD_PATH = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\doctor_dashboard.py"
PATIENT_DASHBOARD_PATH = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\patient_dashboard.py"
SIGNUP_PAGE_PATH = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\signup.py"
HOME_PAGE_PATH = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\home.py"

# Global variable to store logged-in user's ID
current_user_id = None

# Determine greeting based on time of day
current_hour = datetime.now().hour
greeting = "Good Morning" if 5 <= current_hour < 12 else "Good Afternoon" if 12 <= current_hour < 18 else "Good Evening"

# Initialize the main window
root = ctk.CTk()
root.title("Sign In")
root.geometry("1000x700")
root.configure(fg_color="#e8f4ff")

# Display greeting
greeting_label = ctk.CTkLabel(root, text=greeting, font=("Arial", 30, "bold"), text_color="#6e0108")
greeting_label.place(relx=0.5, rely=0.1, anchor="center")

# Welcome message
message_first_line = "Welcome to DocLink: Doctor Any Time"
welcome_label_first = ctk.CTkLabel(root, text=message_first_line, font=("Arial", 40, "bold"), text_color="#011557",
                                   wraplength=800, justify="center")
welcome_label_first.place(relx=0.5, rely=0.18, anchor="center")

# Background frame for form fields
form_frame = ctk.CTkFrame(root, width=400, height=450, corner_radius=20, fg_color="white")
form_frame.place(relx=0.5, rely=0.55, anchor="center")

# Title for the sign-in section
title_label = ctk.CTkLabel(form_frame, text="Sign In", font=("Arial", 24, "bold"), text_color="#011557")
title_label.place(relx=0.5, rely=0.1, anchor="center")

# Email entry field
email_label = ctk.CTkLabel(form_frame, text="Email", font=("Arial", 14, "bold"), text_color="#011557")
email_label.place(relx=0.1, rely=0.25, anchor="w")

email_entry = ctk.CTkEntry(form_frame, width=300, height=35, placeholder_text="example@gmail.com")
email_entry.place(relx=0.1, rely=0.33, anchor="w")

# Password entry field
password_label = ctk.CTkLabel(form_frame, text="Password", font=("Arial", 14, "bold"), text_color="#011557")
password_label.place(relx=0.1, rely=0.45, anchor="w")

password_entry = ctk.CTkEntry(form_frame, width=300, height=35, show="*", placeholder_text="Enter password")
password_entry.place(relx=0.1, rely=0.53, anchor="w")


# Toggle Password Visibility
def toggle_password():
    if show_password_var.get():
        password_entry.configure(show="")
    else:
        password_entry.configure(show="*")


show_password_var = tk.IntVar()
show_password_checkbox = tk.Checkbutton(
    form_frame,
    text="Show Password",
    variable=show_password_var,
    command=toggle_password,
    font=("Arial", 10),
    bg="white",
    activebackground="white",
    fg="black"
)
show_password_checkbox.place(relx=0.55, rely=0.63, anchor="w")


# Function to validate credentials and redirect to the appropriate dashboard
def validate_credentials():
    global current_user_id
    email = email_entry.get()
    password = password_entry.get()

    # Basic validation checks
    if not email or not password:
        messagebox.showerror("Error", "Email and password are required.")
        return

    # Connect to the database and verify credentials
    conn = connect_db()
    cursor = conn.cursor()
    query = "SELECT user_id, role, password FROM users WHERE email = %s"

    try:
        cursor.execute(query, (email,))
        user = cursor.fetchone()

        if user:
            user_id, stored_role, stored_hashed_password = user
            if bcrypt.checkpw(password.encode('utf-8'), stored_hashed_password.encode('utf-8')):
                current_user_id = user_id  # Store user_id globally
                messagebox.showinfo("Success", "Login successful!")
                open_dashboard(stored_role)  # Redirect to the appropriate dashboard
            else:
                messagebox.showerror("Error", "Invalid password.")
        else:
            messagebox.showerror("Error", "User not found.")
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")
    finally:
        cursor.close()
        conn.close()


import subprocess

import subprocess

# Function to open the appropriate dashboard
def open_dashboard(role):
    global current_user_id
    if role == "doctor":
        # Pass `current_user_id` to the doctor dashboard
        subprocess.Popen([sys.executable, DOCTOR_DASHBOARD_PATH, str(current_user_id)])
    elif role == "patient":
        # Pass `current_user_id` to the patient dashboard
        subprocess.Popen([sys.executable, PATIENT_DASHBOARD_PATH, str(current_user_id)])
    root.destroy()  # Close the login window


# Forgot Password Function with Pop-up Window and Show Password Option
def forgot_password():
    forgot_win = ctk.CTkToplevel(root)
    forgot_win.title("Forgot Password")
    forgot_win.geometry("400x500")
    forgot_win.configure(fg_color="#e8f4ff")
    forgot_win.grab_set()  # Keep the pop-up in focus
    forgot_win.focus_set()

    # Forgot Password title
    title_label = ctk.CTkLabel(forgot_win, text="Reset Your Password", font=("Arial", 20, "bold"), text_color="#011557")
    title_label.pack(pady=20)

    # Email entry
    ctk.CTkLabel(forgot_win, text="Enter your email", font=("Arial", 14), text_color="#011557").pack(pady=5)
    email_entry = ctk.CTkEntry(forgot_win, width=300, height=35, placeholder_text="example@gmail.com")
    email_entry.pack(pady=5)

    # New password entry
    ctk.CTkLabel(forgot_win, text="New Password", font=("Arial", 14), text_color="#011557").pack(pady=10)
    new_password_entry = ctk.CTkEntry(forgot_win, width=300, height=35, show="*", placeholder_text="Enter new password")
    new_password_entry.pack(pady=5)

    # Confirm new password entry
    ctk.CTkLabel(forgot_win, text="Confirm New Password", font=("Arial", 14), text_color="#011557").pack(pady=10)
    confirm_password_entry = ctk.CTkEntry(forgot_win, width=300, height=35, show="*", placeholder_text="Confirm password")
    confirm_password_entry.pack(pady=5)

    # Toggle Password Visibility in Forgot Password Window
    def toggle_forgot_password():
        if show_forgot_password_var.get():
            new_password_entry.configure(show="")
            confirm_password_entry.configure(show="")
        else:
            new_password_entry.configure(show="*")
            confirm_password_entry.configure(show="*")

    show_forgot_password_var = tk.IntVar()
    show_password_checkbox = tk.Checkbutton(
        forgot_win,
        text="Show Password",
        variable=show_forgot_password_var,
        command=toggle_forgot_password,
        font=("Arial", 10),
        bg="#e8f4ff",
        activebackground="#e8f4ff",
        fg="black"
    )
    show_password_checkbox.pack(pady=10)

    # Update Password Function
    def update_password():
        email = email_entry.get()
        new_password = new_password_entry.get()
        confirm_password = confirm_password_entry.get()

        # Basic validations
        if not email or not new_password or not confirm_password:
            messagebox.showerror("Error", "All fields are required", parent=forgot_win)
            return
        if new_password != confirm_password:
            messagebox.showerror("Error", "Passwords do not match", parent=forgot_win)
            return
        if len(new_password) < 8 or not re.search(r"[A-Z]", new_password) or not re.search(r"[a-z]", new_password) or not re.search(r"\d", new_password):
            messagebox.showerror("Error", "Password must be 8+ characters with uppercase, lowercase, and numbers", parent=forgot_win)
            return

        # Connect to the database and update the password hash
        conn = connect_db()
        cursor = conn.cursor()
        hashed_new_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        query = "UPDATE users SET password = %s WHERE email = %s"

        try:
            cursor.execute(query, (hashed_new_password, email))
            conn.commit()
            if cursor.rowcount == 0:
                messagebox.showerror("Error", "Email not found", parent=forgot_win)
            else:
                messagebox.showinfo("Success", "Password updated successfully", parent=forgot_win)
                forgot_win.destroy()  # Close the forgot password window
        except Exception as e:
            messagebox.showerror("Error", f"Error: {e}", parent=forgot_win)
        finally:
            cursor.close()
            conn.close()

    # Submit button for the new password
    submit_button = ctk.CTkButton(forgot_win, text="Update Password", command=update_password, font=("Arial", 14),
                                  fg_color="#007bff", text_color="white")
    submit_button.pack(pady=20)


# Forgot Password Link
forgot_password_label = ctk.CTkLabel(form_frame, text="Forgot Password?", font=("Arial", 12, "underline"),
                                     text_color="#007bff", cursor="hand2")
forgot_password_label.place(relx=0.1, rely=0.63, anchor="w")
forgot_password_label.bind("<Button-1>", lambda e: forgot_password())

# Continue button
continue_button = ctk.CTkButton(form_frame, text="Continue", width=300, height=40, font=("Arial", 15, "bold"),
                                fg_color="#007bff", text_color="white", command=validate_credentials)
continue_button.place(relx=0.475, rely=0.75, anchor="center")

# Sign Up Link
def open_signup():
    if os.path.exists(SIGNUP_PAGE_PATH):
        os.system(f'{sys.executable} "{SIGNUP_PAGE_PATH}"')
        root.destroy()
    else:
        messagebox.showerror("Error", f"Sign up page not found at {SIGNUP_PAGE_PATH}")


signup_label = ctk.CTkLabel(form_frame, text="Don't have an account? Sign Up", font=("Arial", 12, "underline"),
                            text_color="#007bff", cursor="hand2")
signup_label.place(relx=0.5, rely=0.83, anchor="center")
signup_label.bind("<Button-1>", lambda e: open_signup())

# Back to Home Link
def back_to_home():
    if os.path.exists(HOME_PAGE_PATH):
        os.system(f'{sys.executable} "{HOME_PAGE_PATH}"')
        root.destroy()
    else:
        messagebox.showerror("Error", f"Home page not found at {HOME_PAGE_PATH}")


back_home_label = ctk.CTkLabel(form_frame, text="Back to Home", font=("Arial", 12, "underline"), text_color="#007bff",
                               cursor="hand2")
back_home_label.place(relx=0.5, rely=0.9, anchor="center")
back_home_label.bind("<Button-1>", lambda e: back_to_home())

root.mainloop()