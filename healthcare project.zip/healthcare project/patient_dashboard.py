import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox
from tkcalendar import DateEntry
from config import connect_db
import subprocess
import sys
import os

# Paths for default profile picture and home page script
DEFAULT_PROFILE_PICTURE_PATH = "C:\\Users\\gampa2g\\PycharmProjects\\pythonProject\\healthcare project\\picture\\profile_icon.png"
HOME_PAGE_PATH = "C:\\Users\\gampa2g\\PycharmProjects\\pythonProject\\healthcare project\\home.py"

# Initialize the main window with theme customization
root = ctk.CTk()
root.title("DocLink - Patient Dashboard")
root.geometry("1200x600")
root.configure(fg_color="#8ea1bf")  # Dark blue background similar to signup page

# Apply a custom theme
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

# Retrieve `user_id` passed as a command-line argument
try:
    current_user_id = int(sys.argv[1])
except (IndexError, ValueError):
    messagebox.showerror("Error", "User ID not provided. Please log in again.")
    sys.exit(1)

# Database functions to fetch and update data
def get_user_data(user_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT first_name, last_name, email, phone_number, address, profile_picture, gender, date_of_birth FROM users WHERE user_id = %s", (user_id,))
    user_data = cursor.fetchone()
    conn.close()
    return user_data

def update_user_data(user_id, first_name, last_name, email, phone_number, address, gender, date_of_birth):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE users
        SET first_name = %s, last_name = %s, email = %s, phone_number = %s, address = %s, gender = %s, date_of_birth = %s
        WHERE user_id = %s
    """, (first_name, last_name, email, phone_number, address, gender, date_of_birth, user_id))
    conn.commit()
    conn.close()


# Function to refresh the main dashboard data
def refresh_dashboard():
    global user_data, user_info_text, user_details
    user_data = get_user_data(current_user_id)
    user_info_text = f"Name: {user_data[0]} {user_data[1]}\nGender: {user_data[6]}\nDate of Birth: {user_data[7]}\nEmail: {user_data[2]}\nPhone: {user_data[3]}\nAddress: {user_data[4]}"
    user_details.configure(text=user_info_text)


import customtkinter as ctk
from tkcalendar import DateEntry
from tkinter import messagebox
import os
import sys
from config import connect_db

# Assuming a separator such as ', ' in the address field for parsing
def parse_address(address):
    parts = address.split(", ")
    street = parts[0] if len(parts) > 0 else ""
    city = parts[1] if len(parts) > 1 else ""
    state = parts[2] if len(parts) > 2 else ""
    zip_code = parts[3] if len(parts) > 3 else ""
    return street, city, state, zip_code

# Profile Editing Window
def open_profile_editor():
    editor = ctk.CTkToplevel(root)
    editor.title("Edit Profile")
    editor.geometry("600x600")
    editor.configure(fg_color="#1a2e49")
    editor.grab_set()  # Ensure the editor stays on top
    editor.transient(root)  # Link window to root so it closes with root

    # Fetch current user data
    user_data = get_user_data(current_user_id)

    # Parse the address into components
    street, city, state, zip_code = parse_address(user_data[4])

    # Fields for editing
    first_name_var = ctk.StringVar(value=user_data[0])
    last_name_var = ctk.StringVar(value=user_data[1])
    email_var = ctk.StringVar(value=user_data[2])
    phone_var = ctk.StringVar(value=user_data[3])
    street_var = ctk.StringVar(value=street)
    city_var = ctk.StringVar(value=city)
    state_var = ctk.StringVar(value=state)
    zip_code_var = ctk.StringVar(value=zip_code)
    gender_var = ctk.StringVar(value=user_data[6])

    # Title
    title_label = ctk.CTkLabel(editor, text="Edit Your DocLink Profile", font=("Helvetica", 22, "bold"), text_color="white")
    title_label.pack(pady=20)

    # Row 1: Full Name
    name_frame = ctk.CTkFrame(editor, fg_color="#1a2e49")
    name_frame.pack(pady=10, padx=30, fill="x")
    first_name_label = ctk.CTkLabel(name_frame, text="First Name", font=("Arial", 12, "bold"), text_color="white")
    first_name_label.grid(row=0, column=0, padx=5)
    first_name_entry = ctk.CTkEntry(name_frame, textvariable=first_name_var, width=180)
    first_name_entry.grid(row=0, column=1, padx=5)

    last_name_label = ctk.CTkLabel(name_frame, text="Last Name", font=("Arial", 12, "bold"), text_color="white")
    last_name_label.grid(row=0, column=2, padx=5)
    last_name_entry = ctk.CTkEntry(name_frame, textvariable=last_name_var, width=180)
    last_name_entry.grid(row=0, column=3, padx=5)

    # Row 2: Date of Birth
    dob_label = ctk.CTkLabel(editor, text="Date of Birth", font=("Arial", 12,"bold"), text_color="white")
    dob_label.pack(anchor="w", padx=30)
    dob_entry = DateEntry(editor, width=18, background="darkblue", foreground="white", date_pattern='yyyy-mm-dd')
    dob_entry.set_date(user_data[7] if user_data[7] else "2000-01-01")  # Set a default date if not available
    dob_entry.pack(pady=5, padx=30, anchor="w")

    # Row 3: Email
    email_label = ctk.CTkLabel(editor, text="Email", font=("Arial", 12, "bold"), text_color="white")
    email_label.pack(anchor="w", padx=30)
    email_entry = ctk.CTkEntry(editor, textvariable=email_var, width=400)
    email_entry.pack(pady=5, padx=30)

    # Row 4: Phone Number
    phone_label = ctk.CTkLabel(editor, text="Phone Number", font=("Arial", 12, "bold"), text_color="white")
    phone_label.pack(anchor="w", padx=30)
    phone_entry = ctk.CTkEntry(editor, textvariable=phone_var, width=400)
    phone_entry.pack(pady=5, padx=30)

    # Row 5: Gender
    gender_label = ctk.CTkLabel(editor, text="Gender", font=("Arial", 12, "bold"), text_color="white")
    gender_label.pack(anchor="w", padx=30)
    gender_dropdown = ctk.CTkOptionMenu(editor, variable=gender_var, values=["Male", "Female", "Other"])
    gender_dropdown.pack(pady=5, padx=30, anchor="w")

    # Row 6: Street Address
    street_address_label = ctk.CTkLabel(editor, text="Street Address", font=("Arial", 12, "bold"), text_color="white")
    street_address_label.pack(anchor="w", padx=30)
    street_address_entry = ctk.CTkEntry(editor, textvariable=street_var, width=400)
    street_address_entry.pack(pady=5, padx=30)

    # Row 7: City, State, Zip Code
    address_frame = ctk.CTkFrame(editor, fg_color="#1a2e49")
    address_frame.pack(pady=10, padx=30, fill="x")

    city_label = ctk.CTkLabel(address_frame, text="City", font=("Arial", 12,"bold"), text_color="white")
    city_label.grid(row=0, column=0, padx=5)
    city_entry = ctk.CTkEntry(address_frame, textvariable=city_var, width=120)
    city_entry.grid(row=0, column=1, padx=5)

    state_label = ctk.CTkLabel(address_frame, text="State", font=("Arial", 12, "bold"), text_color="white")
    state_label.grid(row=0, column=2, padx=5)
    state_entry = ctk.CTkEntry(address_frame, textvariable=state_var, width=120)
    state_entry.grid(row=0, column=3, padx=5)

    zip_code_label = ctk.CTkLabel(address_frame, text="Zip Code", font=("Arial", 12, "bold"), text_color="white")
    zip_code_label.grid(row=0, column=4, padx=5)
    zip_code_entry = ctk.CTkEntry(address_frame, textvariable=zip_code_var, width=80)
    zip_code_entry.grid(row=0, column=5, padx=5)

    # Save button
    def save_profile_changes():
        # Combine address components into one field
        full_address = f"{street_var.get()}, {city_var.get()}, {state_var.get()}, {zip_code_var.get()}"
        update_user_data(
            current_user_id,
            first_name_var.get(),
            last_name_var.get(),
            email_var.get(),
            phone_var.get(),
            full_address,
            gender_var.get(),
            dob_entry.get_date()
        )
        refresh_dashboard()
        editor.destroy()
        messagebox.showinfo("Profile Updated", "Your profile has been updated successfully.")

    save_button = ctk.CTkButton(editor, text="Save Changes", command=save_profile_changes, fg_color="#0072ff", text_color="white", width=200)
    save_button.pack(pady=20)



# Fetch user-specific data for welcome message
user_data = get_user_data(current_user_id)
first_name = user_data[0] if user_data else "User"

# Header Frame
header_frame = ctk.CTkFrame(root, fg_color="#001f4d", height=70)
header_frame.pack(fill="x", padx=20, pady=10)
header_frame.pack_propagate(False)

# Welcome message and DocLink title
welcome_label = ctk.CTkLabel(header_frame, text=f"Hi {first_name}, Welcome to DocLink", font=("Helvetica", 23, "bold"), text_color="#ffffff")
welcome_label.pack(side="left", padx=20)


# Navigation Links
def open_dashboard():
    messagebox.showinfo("Dashboard", "Redirecting to Dashboard")

def sign_out():
    root.destroy()
    os.system(f'{sys.executable} "C:\\Users\\gampa2g\\PycharmProjects\\pythonProject\\healthcare project\\home.py"')

signout_link = ctk.CTkLabel(header_frame, text="Sign Out", font=("Arial", 15, "bold", "underline"), text_color="#ffffff", cursor="hand2")
signout_link.pack(side="right", padx=20)
signout_link.bind("<Button-1>", lambda e: sign_out())

profile_link = ctk.CTkLabel(header_frame, text="Edit Profile", font=("Arial", 15, "bold","underline"), text_color="#ffffff", cursor="hand2")
profile_link.pack(side="right", padx=20)
profile_link.bind("<Button-1>", lambda e: open_profile_editor())  # Opens profile editor



# User Information Section with Profile Picture
user_details_frame = ctk.CTkFrame(root, fg_color="white", corner_radius=10)
user_details_frame.pack(side="left", padx=20, pady=20, fill="both", expand=False)

# Title for User Information
user_info_label = ctk.CTkLabel(user_details_frame, text="User Information", font=("Arial", 18, "bold"), text_color="#001f4d")
user_info_label.grid(row=0, column=0, columnspan=2, pady=10, padx=10, sticky="w")

# Adjust dimensions for the profile picture
try:
    # Resize the profile picture to make it smaller
    from PIL import Image, ImageTk

    profile_image = Image.open(DEFAULT_PROFILE_PICTURE_PATH)
    profile_image = profile_image.resize((180, 180), Image.LANCZOS)  # Resize to 80x80 pixels
    profile_image = ImageTk.PhotoImage(profile_image)
except Exception as e:
    # Fallback to default profile picture if any error occurs
    profile_image = tk.PhotoImage(file=DEFAULT_PROFILE_PICTURE_PATH)

# Add the profile picture
profile_image_label = tk.Label(user_details_frame, image=profile_image, bg="white")
profile_image_label.image = profile_image  # Prevent garbage collection
profile_image_label.grid(row=1, column=1, padx=20, pady=30, sticky="n")

# Display User Details with Gender and Date of Birth included
user_info_text = (
    f"Name: {user_data[0]} {user_data[1]}\n"
    f"Gender: {user_data[6]}\n"
    f"Date of Birth: {user_data[7]}\n"
    f"Email: {user_data[2]}\n"
    f"Phone: {user_data[3]}\n"
    f"Address: {user_data[4]}"
)
user_details = ctk.CTkLabel(user_details_frame, text=user_info_text, font=("Arial", 14), text_color="#666666", justify="left")
user_details.grid(row=3, column=1, padx=20, pady=10, sticky="w")


# Book Appointment and Cancel Appointment Section
def book_appointment():
    script_path = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\book_ an_appointment.py"
    try:
        subprocess.Popen([sys.executable, script_path, str(current_user_id)], shell=True)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open appointment booking: {e}")

def cancel_appointment():
    script_path = r"C:\Users\gampa2g\PycharmProjects\pythonProject\healthcare project\cancle_appoinment.py"
    try:
        subprocess.Popen([sys.executable, script_path, str(current_user_id)], shell=True)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to open appointment cancellation: {e}")

book_appointment_frame = ctk.CTkFrame(root, fg_color="white", width=360, height=300, corner_radius=10)
book_appointment_frame.pack(side="left", padx=20, pady=20, fill="both", expand=True)

book_appointment_label = ctk.CTkLabel(book_appointment_frame, text="Next Appointment", font=("Arial", 16, "bold"), text_color="#333333")
book_appointment_label.pack(anchor="w", padx=20, pady=10)

book_button = ctk.CTkButton(book_appointment_frame, text="Book an Appointment", font=("Arial", 14, "bold"), fg_color="#ff9900", text_color="white", corner_radius=10, command=book_appointment)
book_button.pack(pady=10, padx=20)

cancel_button = ctk.CTkButton(book_appointment_frame, text="Cancel Appointment", font=("Arial", 14, "bold"), fg_color="#ff3300", text_color="white", corner_radius=10, command=cancel_appointment)
cancel_button.pack(pady=10, padx=20)

from tkinter import Canvas, Scrollbar
import customtkinter as ctk  # Assuming you're using CustomTkinter


def get_appointment_history(patient_id):
    """
    Fetches the latest status for each appointment of the given patient.
    """
    conn = connect_db()
    cursor = conn.cursor()

    # Query to get the latest status for each appointment
    query = """
        SELECT 
            a.appointment_id,
            CONCAT(d.first_name, ' ', d.last_name) AS doctor_name,
            doc.specialization,
            doc.clinic_address,
            a.appointment_date,
            a.status
        FROM 
            appointments a
        JOIN 
            doctors doc ON a.doctor_id = doc.doctor_id
        JOIN 
            users d ON doc.user_id = d.user_id
        WHERE 
            a.patient_id = %s
        AND 
            a.appointment_date = (
                SELECT MAX(appointment_date)
                FROM appointments
                WHERE appointment_id = a.appointment_id
            )
        ORDER BY 
            a.appointment_date DESC
    """
    cursor.execute(query, (patient_id,))
    appointments = cursor.fetchall()
    conn.close()
    return appointments



# Function to refresh appointment history
def refresh_appointment_history():
    # Clear the current content in the scrollable frame
    for widget in scrollable_frame.winfo_children():
        widget.destroy()

    # Fetch and populate appointments
    appointments = get_appointment_history(current_user_id)  # Replace with actual user ID
    if appointments:
        for appt in appointments:
            # Fetching the appointment data, but omitting `appointment_id`
            appointment_id, doctor_name, specialization, clinic_address, date, status = appt
            appt_text = (
                f"Doctor: {doctor_name} ({specialization})\n"
                f"Clinic: {clinic_address}\n"
                f"Date: {date}\n"
                f"Status: {status}"
            )

            # Determine text color based on status
            if status.lower() == "booked":
                text_color = "#00008B"  # Dark Blue
            elif status.lower() == "canceled":
                text_color = "#FF0000"  # Red
            elif status.lower() == "completed":
                text_color = "#008000"  # Green
            else:
                text_color = "#333333"  # Default text color for unknown statuses

            # Create the label with the appropriate color
            appt_label = ctk.CTkLabel(scrollable_frame, text=appt_text, font=("Arial", 12), text_color=text_color,
                                      justify="left")
            appt_label.pack(anchor="w", padx=20, pady=5)
    else:
        no_appt_label = ctk.CTkLabel(scrollable_frame, text="No appointments found.", font=("Arial", 12),
                                     text_color="#666666")
        no_appt_label.pack(anchor="w", padx=20, pady=10)


# Main Frame for Appointment History
appointment_history_frame = ctk.CTkFrame(root, fg_color="white", width=360, height=300, corner_radius=10)
appointment_history_frame.pack(side="left", padx=20, pady=20, fill="both", expand=True)

# Header with Label and Refresh Button
header_frame = ctk.CTkFrame(appointment_history_frame, fg_color="white")
header_frame.pack(anchor="w", padx=20, pady=10, fill="x")

appointment_history_label = ctk.CTkLabel(header_frame, text="Appointment History", font=("Arial", 16, "bold"),
                                         text_color="#333333")
appointment_history_label.pack(side="left")

# Adding the refresh button
refresh_button = ctk.CTkButton(
    header_frame,
    text="Refresh",
    font=("Arial", 10),
    command=refresh_appointment_history,
    corner_radius=5,
    fg_color="#007BFF",
    text_color="white"
)
refresh_button.pack(side="right", padx=10)

# Scrollable content area
canvas = Canvas(appointment_history_frame, bg="white", highlightthickness=0)
scrollbar = Scrollbar(appointment_history_frame, orient="vertical", command=canvas.yview)
scrollable_frame = ctk.CTkFrame(canvas, fg_color="white")

scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
)

canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)

canvas.pack(side="left", fill="both", expand=True)
scrollbar.pack(side="right", fill="y")

# Initial Population of Appointment History
refresh_appointment_history()

# Run the main loop
root.mainloop()
