# cleanup_service.py

import threading
from datetime import datetime
import mysql.connector
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

def connect_db():
    """
    Connect to the database using provided credentials.
    """
    return mysql.connector.connect(
        host="141.209.241.57",
        user="gampa2g",
        password="mypass",
        database="BIS698M_GRP6",
        port=3306
    )

def remove_expired_availability():
    """
    Remove expired availability from the doctor_availability table.
    """
    try:
        conn = connect_db()
        cursor = conn.cursor()

        # Get current date and time
        current_datetime = datetime.now()

        # Delete availability where the date and time have passed
        query = """
        DELETE FROM doctor_availability
        WHERE CONCAT(date, ' ', time) < %s
        """
        cursor.execute(query, (current_datetime.strftime('%Y-%m-%d %H:%M:%S'),))
        conn.commit()
        conn.close()

        logging.info("Expired availability removed successfully.")
    except Exception as e:
        logging.error(f"Error removing expired availability: {e}")

def schedule_expired_availability_removal():
    """
    Schedule periodic removal of expired availability every 5 seconds.
    """
    try:
        # Run the availability cleanup
        remove_expired_availability()

        # Schedule this function to run again after 5 seconds
        threading.Timer(5, schedule_expired_availability_removal).start()
    except Exception as e:
        logging.error(f"Error scheduling availability removal: {e}")
